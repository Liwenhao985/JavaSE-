package douyin;

import douyin.entity.User;
import douyin.ui.EntranceUI;
import douyin.ui.HomePageUI;
import douyin.ui.RankingUI;
import douyin.ui.VedioUI;

public class Main {

    public static void main(String[] args) throws Exception {
        EntranceUI en=new EntranceUI();
        HomePageUI hp=new HomePageUI();
        RankingUI rk=new RankingUI();
        VedioUI vd=new VedioUI();
        User user=en.entranceUI();
        System.out.println(user);
        if(user==null){
            System.out.println("系统出错");
            return;
        }

        vd.init(user.getId());
        String choice= vd.vedioUI(user);
        while(true){
            switch (choice){
                case "退出登录"->{
                    user=en.entranceUI();
                    choice="查看首页";//登录后首先是视频页面
                }
                case "查看首页"->{
                    choice= vd.vedioUI(user);
                }
                case "查看排行榜"->{
                    choice=rk.rankingUI(user);
                }
                case "查看主页"->{
                    choice=hp.homePageUI(user);
                }
                default -> {
                    System.out.println("系统出错");
                    return;
                }
            }
        }
    }
}

