package douyin.dao;

import douyin.dao.util.JDBCUtil;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.List;
import java.lang.reflect.Constructor;

public class BaseDAO {

    /**
     * 执行增删改操作的通用方法
     * 该方法用于执行INSERT、UPDATE或DELETE等更新数据库的操作
     * 它接受SQL语句和参数数组（填充占位符）作为输入，执行SQL并返回受影响的行数
     *
     * @param sql SQL语句，可以包含?作为参数占位符
     * @param params 参数数组，用于替换SQL语句中的占位符
     * @return 返回受影响的行数，表示更新操作的结果
     * @throws Exception 如果数据库操作发生错误，则抛出异常
     */
    public int Update(String sql, Object... params) throws Exception {
        // 获取数据库连接
        Connection conn = JDBCUtil.getConnection();
        // 准备SQL语句
        PreparedStatement ps = conn.prepareStatement(sql);
        // 遍历参数数组，设置SQL语句的参数
        for (int i = 0; i < params.length; i++) {
            ps.setObject(i + 1, params[i]);
        }
        // 执行更新操作
        int result = ps.executeUpdate();
        //释放资源
        ps.close();
        // 如果未开启事务，则关闭数据库连接
        if(conn.getAutoCommit()){
            JDBCUtil.closeConnection();
        }
        // 返回受影响的行数
        return result;
    }

    /**
     * 根据给定的SQL查询语句和参数，查询数据库并返回所有数据
     * 该方法使用反射机制根据查询结果动态创建对象列表
     *
     * @param <T> 泛型参数，表示返回的对象类型
     * @param clazz 对象类型的Class对象，用于创建对象实例
     * @param sql SQL查询语句，可以包含占位符
     * @param params 查询语句的参数，用于替换SQL语句中的占位符
     * @return 返回一个包含查询结果的ArrayList列表，列表中的元素类型由clazz指定
     * @throws Exception 如果数据库操作失败或反射调用失败，则抛出异常
     */

public <T> ArrayList<T> selectAll(Class<T> clazz, String sql, Object... params) throws Exception {
    // 获取数据库连接
    Connection conn = JDBCUtil.getConnection();
    // 准备SQL语句
    PreparedStatement ps = conn.prepareStatement(sql);
    // 创建列表，用于存储查询结果对象
    ArrayList<T> list = new ArrayList<>();

    // 如果有参数，则设置参数到PreparedStatement中
    if (params != null && params.length > 0) {
        for (int i = 0; i < params.length; i++) {
            ps.setObject(i + 1, params[i]);
        }
    }

    // 执行查询
    ResultSet rs = ps.executeQuery();
    // 获取查询结果的元数据
    ResultSetMetaData metaData = rs.getMetaData();
    // 获取列的数量
    int columnCount = metaData.getColumnCount();

    // 获取默认构造函数
    //Constructor<T> constructor = clazz.getDeclaredConstructor();
    //constructor.setAccessible(true);

    // 遍历查询结果
    while (rs.next()) {
        if(clazz==Integer.class){
            Integer value = rs.getInt(1);
            list.add((T)value);
        }else if(clazz==String.class){
            String value = rs.getString(1);
            list.add((T)value);
        }else{
            T t=clazz.newInstance();
            // 遍历每一列
            for (int i = 1; i <= columnCount; i++) {
                // 获取列的值
                Object value = rs.getObject(i);
                // 获取列的名称
                String columnName = metaData.getColumnName(i);
                // 根据列名称获取对象的字段
                Field field = clazz.getDeclaredField(columnName);
                // 设置字段可访问
                field.setAccessible(true);
                // 将列的值设置到字段中
                field.set(t, value);
            }
            // 将对象添加到列表中
            list.add(t);
        }
    }

    // 关闭结果集和PreparedStatement
    rs.close();
    ps.close();
    // 如果连接处于自动提交模式，则关闭连接
    if (conn.getAutoCommit()) {
        JDBCUtil.closeConnection();
    }
    // 返回包含查询结果的列表
    return list;
}


    /**
     * 执行SQL查询并返回单个对象
     * 该方法用于执行一个查询操作，并期望得到最多一个结果如果查询结果为空，则返回null
     * 此方法适用于需要获取单个对象的场景，例如根据主键查询记录
     *
     * @param <T>    期望返回的对象类型
     * @param clazz  对象类型的Class，用于映射查询结果到指定的类
     * @param sql    SQL查询语句，应确保查询结果最多为一条记录
     * @param params SQL语句中的参数，用于替换SQL中的占位符
     * @return 返回查询到的对象，如果没有结果则返回null
     * @throws Exception 如果查询过程中发生错误，则抛出异常
     */
    public <T> T selectOne(Class<T> clazz, String sql, Object... params) throws Exception {
        // 调用selectAll方法执行SQL查询并获取结果列表
        ArrayList<T> list = selectAll(clazz, sql, params);
        // 检查查询结果是否非空且不为空列表
        if(list!=null&& !list.isEmpty()){
            // 如果有结果，返回列表中的第一个对象
            return list.get(0);
        }else{
            // 如果没有查询到任何结果，返回null
            return null;
        }
    }
}
