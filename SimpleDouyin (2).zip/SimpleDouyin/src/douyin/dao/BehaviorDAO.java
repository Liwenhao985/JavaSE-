package douyin.dao;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;

public interface BehaviorDAO {
    boolean addBehavior(int userId, int vedioId, String type, LocalDateTime time);

    boolean deleteBehavior(int userId, int vedioId, String type);

    boolean updateDuration(int id, Duration duration);

    ArrayList<Integer> getVedioIdByUserId(int userId);
}
