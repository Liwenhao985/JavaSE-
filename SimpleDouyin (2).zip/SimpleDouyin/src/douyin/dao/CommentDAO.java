package douyin.dao;

import douyin.entity.Comment;

import java.time.LocalDateTime;
import java.util.ArrayList;

public interface CommentDAO {
    boolean review(int userId, int vedioId, int parentId, String content, LocalDateTime time);

    boolean deleteComment(int id,int userId);

    boolean addNormalComment(int userId, int vedioId, String content,LocalDateTime time);

    ArrayList<Comment> getParentCommentByVedioId(int vedioId);
    ArrayList<Comment> getKidCommentByParentId(int parentId);
}
