package douyin.dao;

import java.util.ArrayList;

public interface FollowRelationDAO {
    boolean addFollowRelation(int userId, int followId);
    boolean deleteFollowRelation(int userId, int followId);

    boolean queryIsFollow(int userId, int followId);

    ArrayList<Integer> getFollowIdByUserId(int userId);
    ArrayList<Integer> getUserIdByFollowId(int userId);

    boolean updateTwoWay(int userId, int followId);
    boolean deleteTwoWay(int userId, int followId);
}
