package douyin.dao;

public interface HotDAO {
    public boolean addHot();

    public boolean addLikes(int vedioId);
    public boolean addCollection(int vedioId);
    public boolean addFrequency(int vedioId);

    public boolean cutLikes(int vedioId);
    public boolean cutCollection(int vedioId);
    public boolean cutFrequency(int vedioId);

    public int getLikes(int vedioId);
    public int getCollection(int vedioId);
    public int getFrequency(int vedioId);
}
