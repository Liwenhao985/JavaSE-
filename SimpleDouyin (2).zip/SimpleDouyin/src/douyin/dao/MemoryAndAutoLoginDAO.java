package douyin.dao;

public interface MemoryAndAutoLoginDAO {
    public boolean update(String phone, String password);
    public boolean updateAuto(String phone, String password);
    public boolean deleteAuto(String phone,  String password);
    public boolean delete();
    public String getPhone();
    public String getPassword();
    public int getAuto();
}
