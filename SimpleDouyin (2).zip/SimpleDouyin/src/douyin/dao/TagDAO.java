package douyin.dao;

public interface TagDAO {
    boolean addTag(String name);

    boolean deleteTag(int id);

    int getIdByName(String name);

    int getNumOfTag();
}
