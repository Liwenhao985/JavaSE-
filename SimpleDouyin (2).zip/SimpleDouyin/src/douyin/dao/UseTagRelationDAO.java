package douyin.dao;

import java.util.ArrayList;
import java.util.List;

public interface UseTagRelationDAO {
    boolean addUseTagRelation(int userId, int tagId);

    boolean deleteUseTagRelation(int userId, int tagId);

    boolean addWeight(int userId, int tagId);//weight是根据behavior表中用户id和视频id得到每个标签的喜好占比计算得出

    boolean cutWeight(int userId, int tagId);

    ArrayList<Integer> getTagIdByUserId(int userId);

    int getWeight(int userId, int tagId);
}
