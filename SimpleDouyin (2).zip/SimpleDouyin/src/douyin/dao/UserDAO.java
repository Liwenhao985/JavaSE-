package douyin.dao;

import douyin.entity.User;

import java.util.Date;

public interface UserDAO {
    boolean register(String name, String password, String phone, Date birthday,String gender,
                     String isShow,String headPicture) throws Exception;

    User login(String phone, String password);

    User getUser(int id);

    boolean deleteUser(User user);

    boolean updateName(User user, String name);
    boolean updatePassword(User user, String password);
    boolean updateBirthday(User user, Date birthday);
    boolean updateGender(User user, String gender);
    boolean updateIntroduction(User user, String introduction);
    boolean updateHeadPicture(User user, String headPicture);
    boolean updateIsShow(User user, String isShow);
    boolean updatePhone(User user, String phone);
}
