package douyin.dao;

import java.util.ArrayList;

public interface VedioDAO {
    boolean addVedio(int userId, String path,String name,int tagid,String isShow,
                     String introduction);

    boolean deleteVedio(int id);

    ArrayList<String> getVedioPathByTagId(int tagId);
    int getVedioIdByPath(String path);
    int getTagIdByVedioId(int vedioId);
    int getUserIdByVedioPath(String path);
    ArrayList<String> getVedioPathByUserId(int userId);
    String getVedioNameByVedioId(int vedioId);

    boolean updateIsLegal(int id,String isLegal);
    boolean updateIntroduction(int id,String introduction);
    boolean updateIsShow(int id,String ifShow);
    boolean updateCause(int id,String cause);
}
