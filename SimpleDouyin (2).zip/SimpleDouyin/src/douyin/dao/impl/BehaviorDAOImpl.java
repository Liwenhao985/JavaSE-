package douyin.dao.impl;

import douyin.dao.BaseDAO;
import douyin.dao.BehaviorDAO;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;

public class BehaviorDAOImpl extends BaseDAO implements BehaviorDAO {

    /**
     * 添加用户行为记录
     *
     * @param userId 用户ID，标识用户
     * @param vedioId 视频ID，标识视频
     * @param type 行为类型，描述用户行为（如观看、点赞等）
     * @return boolean 表示行为记录是否成功添加到数据库中
     */
    @Override
    public boolean addBehavior(int userId, int vedioId, String type, LocalDateTime time) {
        try {
            // SQL插入语句，用于在behavior表中添加用户行为记录
            String sql = "insert into behavior(userid,vedioid,type,time) values(?,?,?,?)";
            // 执行更新操作，返回受影响的行数
            int i = Update(sql, userId, vedioId, type,time);
            // 如果受影响的行数大于0，表示记录成功添加
            return i > 0;
        } catch (Exception e) {
            // 异常处理：打印异常信息
            e.printStackTrace();
        }
        // 如果发生异常或未成功添加记录，返回false
        return false;
    }


    /**
     * 根据ID删除行为记录
     *
     * @param userId,vedioId 要删除的行为记录的ID
     * @return 如果删除成功，则返回true；否则返回false
     */
    @Override
    public boolean deleteBehavior(int userId,  int vedioId, String type) {
        try {
            // 定义SQL语句，用于根据ID删除行为记录
            String sql = "delete from behavior where userid=? and vedioid=? and type=?";
            // 执行更新操作，返回影响的行数
            int i = Update(sql, userId,vedioId,type);
            // 如果影响的行数大于0，表示删除成功
            return i > 0;
        } catch (Exception e) {
            // 异常处理：打印异常信息
            e.printStackTrace();
        }
        // 如果发生异常或未删除成功，返回false
        return false;
    }

    /**
     * 更新观看时长的持续时间
     *
     * @param id      行为的唯一标识符
     * @param duration 新的持续时间
     * @return 如果更新成功，则返回true；否则返回false
     */
    @Override
    public boolean updateDuration(int id, Duration duration) {
        try {
            // 定义更新行为持续时间的SQL语句
            String sql = "update behavior set duration=? where id=?";
            // 执行更新操作，并返回受影响的行数
            int i = Update(sql, duration, id);
            // 如果受影响的行数大于0，说明更新成功
            return i > 0;
        } catch (Exception e) {
            // 打印异常信息
            e.printStackTrace();
        }
        // 如果发生异常或更新失败，返回false
        return false;
    }

    /**
     * 根据用户ID获取视频ID列表
     *
     * @param userId 用户ID，用于查询该用户相关的所有视频记录
     * @return 返回一个整型数组列表，包含用户相关的所有视频ID
     *
     * 此方法通过查询数据库中用户行为记录来获取视频ID，使用了预编译SQL语句来防止SQL注入攻击
     * 如果查询过程中发生异常，将抛出运行时异常，便于上层调用者处理
     */
    @Override
    public ArrayList<Integer> getVedioIdByUserId(int userId) {
        try{
            // SQL查询语句，用于从behavior表中根据userid获取所有对应的vedioid
            String sql = "select vedioid from behavior where userid=?";
            // 执行查询并返回结果，此处利用了泛型指定返回值类型为Integer
            return selectAll(Integer.class,sql,userId);
        } catch (Exception e) {
            // 捕获异常并将其转换为运行时异常重新抛出，便于调用者进行异常处理
            throw new RuntimeException(e);
        }
    }
}
