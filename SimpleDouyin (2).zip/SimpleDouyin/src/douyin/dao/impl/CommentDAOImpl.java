package douyin.dao.impl;

import douyin.dao.BaseDAO;
import douyin.dao.CommentDAO;
import douyin.entity.Comment;
import douyin.entity.Vedio;

import java.time.LocalDateTime;
import java.util.ArrayList;

public class CommentDAOImpl extends BaseDAO implements CommentDAO {
    /**
     * 回复评论功能
     *
     * 此方法用于在数据库中插入一条评论该方法重写了父类的方法，以实现特定的评论逻辑
     *
     * @param userId 用户ID，表示评论的用户
     * @param vedioId 视频ID，表示被评论的视频
     * @param parentId 父评论ID，用于支持回复评论的功能
     * @param content 评论内容，用户对视频或其它评论的文字回复
     * @return boolean 返回评论是否成功如果返回true，则表示评论成功；如果返回false，则表示评论失败
     */
    @Override
    public boolean review(int userId, int vedioId, int parentId, String content, LocalDateTime time) {
        try {
            // 准备插入评论的SQL语句
            String sql = "insert into comment(userid,vedioid,parentid,content,time) values(?,?,?,?,?)";
            // 执行SQL语句并返回影响的行数
            int i = Update(sql, userId, vedioId, parentId, content,time);
            // 如果影响的行数大于0，表示评论成功
            return i > 0;
        } catch (Exception e) {
            // 打印异常信息，便于调试和日志记录
            e.printStackTrace();
        }
        // 如果发生异常或插入失败，返回false表示评论失败
        return false;
    }

    /**
     * 删除指定ID的评论
     *
     * @param id 评论的ID
     * @return 如果删除成功返回true，否则返回false
     */
    @Override
    public boolean deleteComment(int id,  int userId) {
        try {
            // 定义SQL语句，用于从comment表中删除指定ID的记录
            String sql = "delete from comment where id=? and userid=?";
            // 执行更新操作，返回受影响的行数
            int i = Update(sql, id,  userId);
            // 如果受影响的行数大于0，表示删除成功
            return i > 0;
        } catch (Exception e) {
            // 异常处理：打印异常信息
            e.printStackTrace();
        }
        // 如果发生异常或未删除成功，返回false
        return false;
    }

    /**
     * 添加普通评论
     *
     * 此方法用于在数据库中插入一条普通评论记录普通评论是指不回复其他评论的评论
     * 它关联到用户和视频，但在数据库中不会有一个父评论ID（parentid为null）
     *
     * @param userId 用户ID，表示评论的作者
     * @param vedioId 视频ID，表示评论关联的视频
     * @param content 评论内容，用户对视频的评价或看法
     * @return boolean 表示评论是否成功添加返回true表示成功，false表示失败
     */
    @Override
    public boolean addNormalComment(int userId, int vedioId, String content, LocalDateTime time) {
        try {
            // SQL语句，用于插入一条新的普通评论到数据库中
            String sql = "insert into comment(userid,vedioid,content,parentid,time) values(?,?,?,null,?)";
            // 执行更新操作，返回受影响的行数
            int i = Update(sql, userId, vedioId, content,time);
            // 如果受影响的行数大于0，表示评论成功添加
            return i > 0;
        } catch (Exception e) {
            // 异常处理：打印异常信息
            e.printStackTrace();
        }
        // 如果发生异常或评论未成功添加，返回false
        return false;
    }

    /**
     * 根据视频ID获取父评论
     * 父评论是指在评论系统中直接对视频进行评论的评论，不包括回复其他评论的子评论
     * 此方法通过查询数据库来获取指定视频的父评论
     *
     * @param vedioId 视频ID，用于查询对应的评论
     * @return 返回父评论的字符串表示如果找不到评论，则返回Comment对象的toString方法的结果
     * @throws RuntimeException 如果查询过程中发生异常，则抛出运行时异常
     */
    @Override
    public ArrayList<Comment> getParentCommentByVedioId(int vedioId) {
        try{
            // SQL查询语句，查找指定视频ID且没有父评论（即父评论ID为null）的评论
            String sql = "select * from comment where vedioid=? and parentid is null";
            // 执行查询，返回一个Comment对象
            ArrayList<Comment> comments = selectAll(Comment.class, sql, vedioId);
            // 返回Comment对象的字符串表示
            return comments;
        } catch (Exception e) {
            // 如果查询过程中发生异常，将其包装为运行时异常并抛出
            throw new RuntimeException(e);
        }
    }

    /**
     * 根据父评论ID获取子评论
     *
     * @param parentId 父评论的ID，用于查询子评论
     * @return 返回子评论的字符串表示，如果不存在则返回空字符串
     *
     * 此方法通过执行SQL查询来获取与给定父评论ID关联的子评论
     * 使用了try-catch块来处理可能发生的异常，确保程序的健壮性
     */
    @Override
    public ArrayList<Comment> getKidCommentByParentId(int parentId) {
        try{
            // SQL查询语句，用于获取指定父评论ID的所有子评论
            String sql = "select * from comment where parentid=?";
            // 执行查询并获取结果，结果为Comment对象
            ArrayList<Comment> commentList = selectAll(Comment.class, sql, parentId);
            // 返回Comment对象的字符串表示
            return commentList;
        } catch (Exception e) {
            // 捕获异常并重新抛出运行时异常，以便调用者可以处理
            throw new RuntimeException(e);
        }
    }
}
