package douyin.dao.impl;

import douyin.dao.BaseDAO;
import douyin.dao.FollowRelationDAO;
import douyin.entity.FollowRelation;
import douyin.entity.User;

import java.util.ArrayList;

public class FollowRelationDAOImpl extends BaseDAO implements FollowRelationDAO {
    /**
     * 添加关注关系到数据库中
     *
     * @param userId   用户ID，表示关注者
     * @param followId 被关注用户ID，表示被关注者
     * @return 返回一个布尔值，表示关注关系是否添加成功
     */
    @Override
    public boolean addFollowRelation(int userId, int followId) {
        try {
            // SQL语句用于在follow_relation表中插入一条关注关系记录
            String sql = "insert into follow_relation(userid,followid) values(?,?)";
            // 执行更新操作，返回受影响的行数
            int i = Update(sql, userId, followId);
            // 如果受影响的行数大于0，表示关注关系添加成功
            return i > 0;
        } catch (Exception e) {
            // 异常处理：打印异常信息
            e.printStackTrace();
        }
        // 如果执行到此处，表示关注关系添加失败，返回false
        return false;
    }

    /**
     * 删除用户关注关系
     *
     * 本方法旨在删除用户与被关注用户之间的关注关系通过指定的用户ID和被关注用户ID
     * 来确定关注关系，并从数据库中移除这条关系
     *
     * @param userId   用户ID，表示关注发起者的唯一标识
     * @param followId 被关注用户ID，表示关注接收者的唯一标识
     * @return boolean 表示关注关系是否删除成功返回true表示成功，false表示失败
     */
    @Override
    public boolean deleteFollowRelation(int userId, int followId) {
        try {
            // 定义SQL语句，用于从follow_relation表中删除指定的用户关注关系
            String sql = "delete from follow_relation where userid=? and followid=?";
            // 执行更新操作，参数为SQL语句、用户ID和被关注用户ID
            int i = Update(sql, userId, followId);
            // 如果返回值大于0，表示有关注关系被删除成功，返回true
            return i > 0;
        } catch (Exception e) {
            // 异常处理：打印异常信息
            e.printStackTrace();
        }
        // 如果发生异常或未删除成功，返回false
        return false;
    }

    @Override
    public boolean queryIsFollow(int userId, int followId) {
        try{
            String sql="select * from follow_relation where userid=? and followid=?";
            FollowRelation followRelation=selectOne(FollowRelation.class,sql,userId,followId);
            if(followRelation!=null){
                return true;
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return false;
    }

    /**
     * 更新双向关注关系
     * 当两个用户互相关注时，将数据库中的关注关系标记为双向关注
     *
     * @param userId 用户ID，表示当前操作的用户
     * @param followId 被关注用户ID，表示当前用户关注的目标用户
     * @param isFollow 字符串，表示是否为双向关注关系通常为"1"或"0"
     * @return boolean 返回更新操作是否成功，如果两个更新操作都成功则返回true，否则返回false
     */
    @Override
    public boolean updateTwoWay(int userId, int followId) {
        try {
            // 查询用户之间的关注关系
            FollowRelation f1=selectOne(FollowRelation.class,"select * from follow_relation where userid=? and followid=?",userId,followId);
            FollowRelation f2=selectOne(FollowRelation.class,"select * from follow_relation where userid=? and followid=?",followId,userId);
            // 如果任一方向的关注关系不存在，则返回false
            if(f1==null||f2==null){
                return false;
            }
            // 更新双向关注关系的SQL语句
            String sql = "update follow_relation set two_way='yes' where userid=? and followid=?";
            // 执行更新操作，确保两个方向的关注关系都被标记为双向关注
            int i = Update(sql, userId, followId);
            int j= Update(sql, followId, userId);
            // 只有当两个更新操作都成功时，才返回true
            return i > 0&& j>0;
        } catch (Exception e) {
            // 异常处理：打印异常信息
            e.printStackTrace();
        }
        // 如果发生异常或更新操作失败，则返回false
        return false;
    }
    @Override
    public boolean deleteTwoWay(int userId, int followId) {
        try {
            // 删除双向关注关系的SQL语句
            String sql = "update follow_relation set two_way='no' where userid=? and followid=?";
            // 执行更新操作，将两个方向的关注关系标记为单向关注
            int i = Update(sql, userId, followId);
            int j= Update(sql, followId, userId);
            // 只有当两个更新操作都成功时，才返回true
            return i > 0&& j>0;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public ArrayList<Integer> getFollowIdByUserId(int userId) {
        try{
            String sql="select followid from follow_relation where userid=?";
            ArrayList<Integer> followList=selectAll(Integer.class,sql,userId);
            return followList;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public ArrayList<Integer> getUserIdByFollowId(int userId) {
        try{
            String sql="select userid from follow_relation where followid=?";
            return selectAll(Integer.class,sql,userId);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
