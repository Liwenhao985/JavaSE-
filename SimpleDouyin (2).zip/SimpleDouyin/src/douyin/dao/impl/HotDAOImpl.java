package douyin.dao.impl;

import douyin.dao.BaseDAO;
import douyin.dao.HotDAO;

public class HotDAOImpl extends BaseDAO implements HotDAO {
    @Override
    public boolean addHot(){
        try{
            String sql = "insert into hot values()";
            return Update(sql) > 0;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public boolean addLikes(int vedioId){
        try{
            String sql = "update hot set likes = likes + 1 where id = ?";
            return Update(sql, vedioId) > 0;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    @Override
    public boolean addCollection(int vedioId){
        try{
            String sql = "update hot set collection = collection + 1 where id = ?";
            return Update(sql, vedioId) > 0;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    @Override
    public boolean addFrequency(int vedioId){
        try{
            String sql = "update hot set frequency = frequency + 1 where id = ?";
            return Update(sql, vedioId) > 0;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public boolean cutLikes(int vedioId){
        try{
            String sql = "update hot set likes = likes - 1 where id = ?";
            return Update(sql, vedioId) > 0;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    @Override
    public boolean cutCollection(int vedioId){
        try{
            String sql = "update hot set collection = collection - 1 where id = ?";
            return Update(sql, vedioId) > 0;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    @Override
    public boolean cutFrequency(int vedioId){
        try{
            String sql = "update hot set frequency = frequency - 1 where id = ?";
            return Update(sql, vedioId) > 0;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public int getLikes(int vedioId){
        try{
            String sql = "select likes from hot where id = ?";
            return selectOne(Integer.class, sql, vedioId);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    @Override
    public int getCollection(int vedioId){
        try{
            String sql = "select collection from hot where id = ?";
            return selectOne(Integer.class, sql, vedioId);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    @Override
    public int getFrequency(int vedioId){
        try{
            String sql = "select frequency from hot where id = ?";
            return selectOne(Integer.class, sql, vedioId);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
