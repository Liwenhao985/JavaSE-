package douyin.dao.impl;

import douyin.dao.BaseDAO;
import douyin.dao.MemoryAndAutoLoginDAO;

public class MemoryAndAutoLoginDAOImpl extends BaseDAO implements MemoryAndAutoLoginDAO {

    @Override
    public boolean update(String phone, String password) {
        String sql = "update memory_autologin set password = ? , phone = ? where id = 1";
        try {
            return Update(sql, password, phone) > 0 && updateAuto(phone, password);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean updateAuto(String phone, String password) {
        String sql = "update memory_autologin set auto=1 where id=1";
        try {
            return Update(sql) > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    @Override
    public boolean deleteAuto(String phone, String password) {
        String sql = "update memory_autologin set auto=0 where id=1";
        try {
            return Update(sql) > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean delete() {
        return update("11111111111", "1")&&deleteAuto("11111111111", "1");
    }

    @Override
    public String getPhone() {
        String sql = "select phone from memory_autologin where id = 1";
        try {
            String phone = selectOne(String.class, sql);
            return phone;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public String getPassword() {
        String sql = "select password from memory_autologin where id = 1";
        try {
            String password = selectOne(String.class, sql);
            return password;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public int getAuto() {
        String sql = "select auto from memory_autologin where id = 1";
        try {
            int auto = selectOne(Integer.class, sql);
            return auto;
        } catch (Exception e) {
//            e.printStackTrace();
        }
        return 2;
    }
}
