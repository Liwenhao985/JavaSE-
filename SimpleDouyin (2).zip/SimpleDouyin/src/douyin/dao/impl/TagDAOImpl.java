package douyin.dao.impl;

import douyin.dao.BaseDAO;
import douyin.dao.TagDAO;
import douyin.entity.Tag;

public class TagDAOImpl extends BaseDAO implements TagDAO {
    /**
     * 添加标签
     *
     * 此方法用于向数据库中插入一个新的标签记录
     * 它使用SQL语句来执行插入操作，并处理可能发生的异常
     *
     * @param name 标签的名称，是插入数据库的唯一信息
     * @return 返回一个布尔值，表示标签是否成功添加到数据库中
     *         true表示成功添加，false表示添加失败
     */
    @Override
    public boolean addTag(String name) {
        try {
            // 定义SQL语句，用于向tag表中插入一条记录
            String sql = "insert into tag(name) values(?)";
            // 执行更新操作，将name参数插入到SQL语句中
            Update(sql, name);
            // 如果执行到这里，说明标签已成功添加，返回true
            return true;
        } catch (Exception e) {
            // 捕获并打印异常信息，以便于问题追踪和定位
            e.printStackTrace();
        }
        // 如果发生异常，返回false，表示标签添加失败
        return false;
    }

    /**
     * 根据标签ID删除标签
     *
     * @param id 标签的ID，用于标识要删除的标签
     * @return 如果删除成功，返回true；否则返回false
     */
    @Override
    public boolean deleteTag(int id) {
        try {
            // 定义SQL语句，用于从数据库中删除指定ID的标签
            String sql = "delete from tag where id = ?";
            // 执行更新操作，将id作为参数传递给SQL语句
            Update(sql, id);
            // 如果执行到这里，说明删除操作成功，返回true
            return true;
        } catch (Exception e) {
            // 捕获异常，打印异常信息
            e.printStackTrace();
            // 如果执行到这里，说明删除操作失败，返回false
        }
        return false;
    }

    /**
     * 根据名称获取标签ID
     *
     * 此方法通过名称查询标签（Tag）对象，并返回该标签的ID
     * 它使用SQL查询来检索数据，并利用ORM框架（如myBatis或JPA）来映射结果到Tag对象
     *
     * @param name 标签名称，用于查询的唯一标识
     * @return 标签的ID，如果未找到匹配的标签，则抛出运行时异常
     * @throws RuntimeException 当数据库查询失败或无法找到匹配的标签时抛出
     */
    @Override
    public int getIdByName(String name) {
        try{
            // SQL查询语句，用于根据名称查询标签的ID
            String sql = "select id from tag where name = ?";
            // 执行查询，并获取结果
            Tag tag = selectOne(Tag.class, sql, name);
            if (tag == null) {
                // 如果查询结果为空，抛出运行时异常
                return 0;
            }
            // 返回标签的ID
            return tag.getId();
        } catch (Exception e) {
            // 当查询失败或无法找到匹配的标签时，抛出运行时异常
            throw new RuntimeException(e);
        }
    }

    @Override
    public int getNumOfTag() {
        try {
            // SQL查询语句，用于获取标签的数量
            String sql = "select count(*) from tag";
            // 执行查询，并获取结果
            Integer num = selectOne(Integer.class, sql);
            if (num == null) {
                // 如果查询结果为空，抛出运行时异常
                return 0;
            }
            // 返回标签的数量
            return num;
        } catch (Exception e) {
            // 当查询失败时，抛出运行时异常
            throw new RuntimeException(e);
        }
    }
}
