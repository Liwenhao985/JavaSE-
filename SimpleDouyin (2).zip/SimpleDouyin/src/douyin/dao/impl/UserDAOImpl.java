package douyin.dao.impl;

import douyin.dao.BaseDAO;
import douyin.dao.UserDAO;
import douyin.entity.User;

import java.util.Date;

public class UserDAOImpl extends BaseDAO implements UserDAO {
    /**
     * 注册用户方法
     *
     * 该方法用于向系统中注册一个新用户它接受用户的姓名、密码、电话、生日、性别、是否展示以及头像信息，
     * 并尝试将这些信息插入到数据库的用户表中如果插入成功，返回true，表示注册成功；
     * 否则返回false，表示注册失败此方法体现了对用户信息的基本操作，是系统用户管理功能的基础
     *
     * @param name 用户名，用于标识用户
     * @param password 用户密码，用于验证用户身份
     * @param phone 用户电话，用于联系用户
     * @param birthday 用户生日，用于个性化推荐或祝福
     * @param gender 用户性别，'M'代表男性，'F'代表女性，用于个性化设置
     * @param isShow 用户可见性，"1"表示用户信息可见，"0"表示用户信息隐藏
     * @param headPicture 用户头像路径，用于用户界面展示
     * @return boolean 表示注册是否成功，返回true表示成功，返回false表示失败
     * @throws Exception 当数据库操作失败时抛出异常
     */
    @Override
    public boolean register(String name, String password, String phone, Date birthday, String gender, String isShow, String headPicture) throws Exception {
        try {
            // 检查数据库中是否已经存在相同电话号码和密码的用户
            User user=selectOne(User.class, "select * from user where phone = ? and password = ?", phone, password);
            if(user!=null){
                return false;
            }
            // 执行SQL语句插入用户信息到数据库
            int i = Update("insert into user(name,password,phone,birthday,gender,isShow,headPicture) values(?,?,?,?,?,?,?)",
                    name, password, phone, birthday, gender, isShow, headPicture);
            // 判断插入操作是否成功，并返回结果
            return i>0;
        } catch (Exception e) {
            // 如果发生异常，抛出RuntimeException，便于上层调用者处理异常
            throw new RuntimeException(e);
        }
    }

    /**
     * 用户登录方法
     *
     * 该方法尝试通过电话号码和密码在数据库中查询匹配的用户信息
     * 如果查询成功，返回用户对象；如果查询失败或发生异常，返回null
     *
     * @param phone 用户注册时使用的电话号码，用于唯一标识用户
     * @param password 用户设定的登录密码，用于验证用户身份
     * @return 如果找到匹配的用户信息，则返回该用户对象；否则返回null
     */
    @Override
    public User login(String phone, String password) {
        try {
            // 尝试从数据库中查询与提供的电话号码和密码匹配的用户
            User user = selectOne(User.class, "select * from user where phone = ? and password = ?", phone, password);
            return user;
        } catch (Exception e) {
            // 当查询过程中发生异常时，打印异常信息
            e.printStackTrace();
        }
        // 如果查询失败或发生异常，返回null
        return null;
    }

    /**
     * 根据用户ID获取用户对象
     * 此方法使用SQL查询来获取用户信息，如果找到匹配的用户，则返回该用户对象；否则返回null
     * 它还处理查询过程中可能发生的异常，以避免程序崩溃
     *
     * @param id 用户ID，数据库中用户的唯一标识
     * @return 如果找到匹配的用户，则返回User对象；否则返回null
     */
    @Override
    public User getUser(int id) {
        try {
            // 使用用户ID作为参数执行SQL查询，尝试从数据库中获取用户对象
            User user = selectOne(User.class, "select * from user where id = ?", id);
            return user;
        } catch (Exception e) {
            // 当查询过程中发生异常时，打印异常信息，以便调试和日志记录
            e.printStackTrace();
        }
        // 如果查询失败或没有找到用户，返回null
        return null;
    }

    /**
     * 删除用户信息
     *
     * 该方法旨在从数据库中删除指定的用户记录它通过调用Update方法执行SQL语句，
     * 该SQL语句根据用户ID删除用户表中的记录如果删除操作成功（即数据库中存在该用户，
     * 并且删除成功），则返回true；否则返回false
     *
     * @param user 要删除的用户对象，不能为空该用户对象的ID属性用于标识数据库中的用户记录
     * @return boolean 表示删除操作是否成功true表示成功删除至少一行用户记录，
     *         false表示删除操作未成功执行或未删除任何记录
     */
    @Override
    public boolean deleteUser(User user) {
        try {
            // 执行删除操作，根据用户ID删除记录
            int i = Update("delete from user where id = ?", user.getId());
            // 如果删除的行数大于0，表示删除成功
            return i > 0;
        } catch (Exception e) {
            // 异常处理：打印异常信息
            e.printStackTrace();
        }
        // 如果发生异常或删除操作未成功，则返回false
        return false;
    }

    @Override
    public boolean updateName(User user, String name) {
        try {
            int i = Update("update user set name = ? where id = ?", name, user.getId());
            return i>0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    @Override
    public boolean updatePassword(User user, String password) {
        try {
            int i = Update("update user set password = ? where id = ?", password, user.getId());
            return i>0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    @Override
    public boolean updateBirthday(User user, Date birthday) {
        try {
            int i = Update("update user set birthday = ? where id = ?", birthday, user.getId());
            return i>0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    @Override
    public boolean updateGender(User user, String gender) {
        try {
            int i = Update("update user set gender = ? where id = ?", gender, user.getId());
            return i>0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    @Override
    public boolean updateIntroduction(User user, String introduction) {
        try {
            int i = Update("update user set introduction = ? where id = ?", introduction, user.getId());
            return i>0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    @Override
    public boolean updateHeadPicture(User user, String headPicture) {
        try {
            int i = Update("update user set headPicture = ? where id = ?", headPicture, user.getId());
            return i>0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    @Override
    public boolean updateIsShow(User user, String isShow) {
        try {
            int i = Update("update user set isShow = ? where id = ?", isShow, user.getId());
            return i>0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    @Override
    public boolean updatePhone(User user, String phone) {
        try {
            int i = Update("update user set phone = ? where id = ?", phone, user.getId());
            return i>0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}
