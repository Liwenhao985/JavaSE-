package douyin.dao.impl;

import douyin.dao.BaseDAO;
import douyin.dao.UseTagRelationDAO;

import java.util.ArrayList;

public class UserTagRelationDAOImpl extends BaseDAO implements UseTagRelationDAO {
    /**
     * 添加用户和标签之间的关系
     *
     * @param userId 用户ID，标识用户的唯一性
     * @param tagId 标签ID，标识标签的唯一性
     * @return 如果成功添加关系，返回true；否则，返回false
     */
    @Override
    public boolean addUseTagRelation(int userId, int tagId) {
        try {
            // SQL语句，用于在user_tag_relation表中插入用户和标签的关系
            String sql = "insert into user_tag_relation(userid,tagid,weight) values(?,?,1)";
            // 执行更新操作，返回受影响的行数
            int i = Update(sql, userId, tagId);
            // 如果受影响的行数大于0，表示成功添加关系，返回true
            return i > 0;
        } catch (Exception e) {
            // 异常处理：打印异常信息
            e.printStackTrace();
        }
        // 如果发生异常或插入失败，返回false
        return false;
    }

    /**
     * 删除用户和标签之间的关联关系
     *
     * @param userId 用户ID，用于标识用户
     * @param tagId 标签ID，用于标识标签
     * @return 如果成功删除关联关系，则返回true；否则返回false
     */
    @Override
    public boolean deleteUseTagRelation(int userId, int tagId) {
        try {
            // 定义SQL语句，用于从user_tag_relation表中删除指定用户和标签的关联关系
            String sql = "delete from user_tag_relation where userid=? and tagid=?";
            // 执行更新操作，返回影响的行数
            int i = Update(sql, userId, tagId);
            // 如果影响的行数大于0，表示删除成功
            return i > 0;
        } catch (Exception e) {
            // 打印异常信息，便于调试和日志记录
            e.printStackTrace();
        }
        // 如果发生异常或未删除成功，返回false
        return false;
    }

    /**
     * 为指定用户和标签的关联增加权重
     * 此方法通过更新数据库中的user_tag_relation表来实现
     * 当用户对某个标签的权重增加时，表明该用户与该标签的相关性增强
     *
     * @param userId 用户ID，用于标识数据库中的用户
     * @param tagId 标签ID，用于标识数据库中的标签
     * @return 返回一个布尔值，表示权重更新是否成功 如果更新成功，返回true；否则，返回false
     */
    @Override
    public boolean addWeight(int userId, int tagId) {
        try {
            // 定义SQL语句，用于更新用户和标签关联的权重
            String sql = "update user_tag_relation set weight=weight+1 where userid=? and tagid=?";
            // 执行更新操作，返回受影响的行数
            int i = Update(sql, userId, tagId);
            // 如果受影响的行数大于0，说明权重更新成功
            return i > 0;
        } catch (Exception e) {
            // 异常处理：打印异常信息
            e.printStackTrace();
        }
        // 如果更新操作失败，返回false
        return false;
    }

    /**
     * 重写cutWeight方法，用于减少用户对某个标签的权重
     *
     * @param userId 用户ID，用于标识用户
     * @param tagId 标签ID，用于标识特定的标签
     * @return boolean 返回操作是否成功，如果权重成功减少，则返回true，否则返回false
     */
    @Override
    public boolean cutWeight(int userId, int tagId) {
        try {
            // 定义SQL语句，用于更新用户和标签之间的权重，将其减少1
            String sql = "update user_tag_relation set weight=weight-1 where userid=? and tagid=?";
            // 执行更新操作，传递用户ID和标签ID作为参数
            int i = Update(sql, userId, tagId);
            // 检查更新操作是否成功，如果成功，返回true
            return i > 0;
        } catch (Exception e) {
            // 捕获异常并打印堆栈跟踪，以便于调试和日志记录
            e.printStackTrace();
        }
        // 如果发生异常或更新操作失败，返回false
        return false;
    }

    @Override
    public ArrayList<Integer> getTagIdByUserId(int userId) {
        try {
            // 定义SQL语句，用于查询指定用户关联的所有标签的ID
            String sql = "select tagid from user_tag_relation where userid=?";
            // 调用selectAll方法，传入Tag类和SQL语句，并传递用户ID作为参数
            ArrayList<Integer> tagIds = selectAll(Integer.class, sql, userId);
            // 返回查询结果，即用户关联的所有标签的ID列表
            return tagIds;
       } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public int getWeight(int userId, int tagId) {
        try {
            // 定义SQL语句，用于查询指定用户和标签的权重
            String sql = "select weight from user_tag_relation where userid=? and tagid=?";
            // 调用selectOne方法，传入Integer类和SQL语句，并传递用户ID和标签ID作为参数
            Integer weight = selectOne(Integer.class, sql, userId, tagId);
            // 如果查询结果不为空，返回权重值
            if (weight != null){
                return weight;
            }
            return 0;
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }
}
