package douyin.dao.impl;

import douyin.dao.BaseDAO;
import douyin.dao.VedioDAO;
import douyin.entity.Vedio;

import java.util.ArrayList;

public class VedioDAOImpl extends BaseDAO implements VedioDAO {
    /**
     * 添加视频方法
     *
     * @param userId 用户ID，用于关联视频和用户
     * @param path 视频文件路径
     * @param name 视频名称
     * @param tagid 视频标签ID，用于分类视频
     * @param isShow 是否展示，表示视频是否对用户可见
     * @param introduction 视频简介
     * @return 返回一个布尔值，表示视频是否成功添加到数据库中
     */
    @Override
    public boolean addVedio(int userId, String path, String name, int tagid, String isShow, String introduction) {
        try {
            // SQL插入语句，用于向数据库中添加视频信息
            String sql = "insert into vedio(userid,path,name,tagid,isShow,introduction) values(?,?,?,?,?,?)";
            // 执行更新操作，返回受影响的行数
            int i = Update(sql, userId, path, name, tagid, isShow, introduction);
            // 如果受影响的行数大于0，表示添加成功
            return i > 0;
        } catch (Exception e) {
            // 异常处理，打印异常信息
            e.printStackTrace();
        }
        // 默认返回值，表示添加失败
        return false;
    }

    /**
     * 根据视频ID删除视频信息
     *
     * @param id 视频的ID，用于定位要删除的视频记录
     * @return 如果删除成功，则返回true；否则返回false
     */
    @Override
    public boolean deleteVedio(int id) {
        try {
            // 定义SQL语句，用于从vedio表中删除指定ID的记录
            String sql = "delete from vedio where id=?";
            // 执行更新操作，返回受影响的行数
            int i = Update(sql, id);
            // 如果受影响的行数大于0，表示删除成功
            return i > 0;
        } catch (Exception e) {
            // 异常处理：打印异常信息
            e.printStackTrace();
        }
        // 如果发生异常或未删除成功，返回false
        return false;
    }

    /**
     * 根据标签ID获取视频路径
     *
     * 此方法通过标签ID来查询数据库中对应的视频路径它使用预编译的SQL语句来提高查询效率，
     * 并且调用selectOne方法来执行查询操作如果查询成功，它将返回视频路径；
     * 如果查询失败或出现异常，它将打印异常信息并返回null
     *
     * @param tagId 标签ID，用于查询视频路径
     * @return 视频路径，如果查询失败或出现异常则返回null
     */
    @Override
    public ArrayList<String> getVedioPathByTagId(int tagId) {
        try{
            String sql = "select path from vedio where tagid=?";
            ArrayList<String> paths = selectAll(String.class, sql, tagId);
            return paths;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * 根据视频路径获取视频ID
     *
     * 此方法通过查询数据库来获取与给定路径关联的视频ID它使用预编译的SQL语句来防止SQL注入攻击，
     * 并利用ORM框架的selectOne方法来简化数据访问层的代码
     *
     * @param path 视频文件的路径，用于查询数据库中的视频记录
     * @return 返回查询到的视频ID如果没有找到匹配的记录，则返回0
     */
    @Override
    public int getVedioIdByPath(String path) {
        try {
            // SQL查询语句，用于从vedio表中根据路径查询视频记录
            String sql = "select id from vedio where path=?";
            // 使用ORM框架的selectOne方法执行查询，并将结果转换为Vedio对象
            Vedio vedio = selectOne(Vedio.class, sql, path);
            if (vedio == null) {
                // 如果查询结果为空，则返回默认值0
                return 0;
            }
            // 返回查询到的视频ID
            return vedio.getId();
        } catch (Exception e) {
            // 打印异常信息，便于调试和日志记录
            e.printStackTrace();
        }
        // 如果查询过程中发生异常或者没有找到匹配的记录，返回默认值0
        return 0;
    }

    /**
     * 根据视频ID获取标签ID
     *
     * 此方法通过视频ID查询数据库中的vedio表，以获取对应的标签ID它假设数据库中已经存在
     * 一个映射关系，即每个视频都关联了一个标签ID
     *
     * @param vedioId 视频ID，用于查询的唯一标识
     * @return 标签ID，如果查询成功则返回标签ID，否则返回0
     *
     * 注意：此方法使用了JDBC或类似技术进行数据库操作，且仅返回一个标签ID，
     * 这意味着它预期每个视频仅关联一个标签这种设计可能不适用于多标签场景
     */
    @Override
    public int getTagIdByVedioId(int vedioId) {
        try {
            // SQL查询语句，用于根据视频ID获取标签ID
            String sql = "select tagid from vedio where id=?";
            // 执行查询，并获取结果
            Vedio vedio = selectOne(Vedio.class, sql, vedioId);
            if (vedio == null) {
                // 如果查询结果为空，则返回默认值0
                return 0;
            }
            // 返回查询到的标签ID
            return vedio.getTagId();
        } catch (Exception e) {
            // 异常处理：打印异常信息
            e.printStackTrace();
        }
        // 如果发生异常或未找到视频，则返回默认值0
        return 0;
    }

    /**
     * 根据视频路径获取用户ID
     *
     * 此方法通过查询数据库来获取与特定视频路径关联的用户ID
     * 它使用预编译的SQL语句来防止SQL注入攻击，并提高查询效率
     *
     * @param path 视频的存储路径，用于查询用户ID
     * @return 如果找到对应的用户ID，则返回该用户ID；否则返回0
     */
    @Override
    public int getUserIdByVedioPath(String path) {
        try {
            // SQL查询语句，用于从vedio表中根据路径查询userid
            String sql = "select userid from vedio where path=?";
            // 执行查询，获取与指定路径关联的Vedio对象
            Vedio vedio = selectOne(Vedio.class, sql, path);
            if (vedio == null) {
                // 如果查询结果为空，则返回默认值0
                return 0;
            }
            // 返回查询到的Vedio对象的userid
            return vedio.getUserid();
        } catch (Exception e) {
            // 打印异常信息，便于调试和日志记录
            e.printStackTrace();
        }
        // 如果发生异常或未找到记录，则返回默认值0
        return 0;
    }

    @Override
    public ArrayList<String> getVedioPathByUserId(int userId) {
        try {
            String sql = "select path from vedio where userid=?";
            ArrayList<String> paths = selectAll(String.class, sql, userId);
            return paths;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public String getVedioNameByVedioId(int vedioId) {
        try {
            String sql = "select name from vedio where id=?";
            Vedio vedio = selectOne(Vedio.class, sql, vedioId);
            if (vedio == null) {
                return null;
            }
            return vedio.getName();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public boolean updateIsLegal(int id, String isLegal) {
        try {
            String sql = "update vedio set islegal=? where id=?";
            int i=Update(sql, isLegal, id);
            return i>0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean updateIntroduction(int id, String introduction) {
        try {
            String sql = "update vedio set introduction=? where id=?";
            int i=Update(sql, introduction, id);
            return i>0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean updateIsShow(int id, String ifShow) {
        try {
            String sql = "update vedio set ifshow=? where id=?";
            int i=Update(sql, ifShow, id);
            return i>0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean updateCause(int id, String cause) {
        try {
            String sql = "update vedio set cause=? where id=?";
            int i=Update(sql, cause, id);
            return i>0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}
