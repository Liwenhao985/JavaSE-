package douyin.entity;

import java.time.Duration;
import java.time.LocalDateTime;

public class Behavior {
    private int id;
    private int userid;
    private int vedioid;
    private String type;
    private LocalDateTime time;

    public Behavior() {
        this.time = LocalDateTime.now();
    }

    public Behavior(int userid, int vedioid, String type) {
        this.userid = userid;
        this.vedioid = vedioid;
        this.type = type;
        this.time = LocalDateTime.now();
    }

    public int getId() {
        return id;
    }

    public LocalDateTime getTime() {
        return time;
    }

    public int getUserid() {
        return userid;
    }

    public void setUserid(int userid) {
        this.userid = userid;
    }

    public int getVedioid() {
        return vedioid;
    }

    public void setVedioid(int vedioid) {
        this.vedioid = vedioid;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "Behavior{" +
                "id=" + id +
                ", userid=" + userid +
                ", vedioid=" + vedioid +
                ", type='" + type + '\'' +
                ", time=" + time +
                '}';
    }
}
