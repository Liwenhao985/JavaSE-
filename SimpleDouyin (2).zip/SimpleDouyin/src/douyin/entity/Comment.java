package douyin.entity;

import java.time.LocalDateTime;

public class Comment {
    private int id;
    private int userid;
    private int vedioid;
    private Integer parentid=0;
    private String content;
    private LocalDateTime time;

    public Comment() {
        this.time = LocalDateTime.now();
    }

    public Comment(int userid, int vedioid, Integer parentid, String content) {
        this.userid = userid;
        this.vedioid = vedioid;
        this.parentid = parentid;
        this.content = content;
        this.time = LocalDateTime.now();
    }

    public int getId() {
        return id;
    }

    public int getUserid() {
        return userid;
    }

    public void setUserid(int userid) {
        this.userid = userid;
    }

    public int getVedioid() {
        return vedioid;
    }

    public void setVedioid(int vedioid) {
        this.vedioid = vedioid;
    }

    public int getParentid() {
        return parentid;
    }

    public void setParentid(int parentid) {
        this.parentid = parentid;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public LocalDateTime getTime() {
        return time;
    }

    @Override
    public String toString() {
        if(parentid==0){
            return "用户"+getUserid()+":"+getContent()+"  "+getTime()+"(评论ID:"+getId()+")";
        }else{
            return "用户"+getUserid()+":"+getContent()+"  "+getTime()+"(评论ID:"+getId()+")";
        }
    }
}
