package douyin.entity;

public class FollowRelation {
    private int id;
    private int userid;
    private int followid;
    private String two_way;

    public FollowRelation() {
    }

    public FollowRelation(int userid, int followid, String twoWay) {
        this.userid = userid;
        this.followid = followid;
        this.two_way = twoWay;
    }

    public int getId() {
        return id;
    }

    public int getUserid() {
        return userid;
    }

    public void setUserid(int userid) {
        this.userid = userid;
    }

    public int getFollowid() {
        return followid;
    }

    public void setFollowid(int followid) {
        this.followid = followid;
    }

    public String getTwoWay() {
        return two_way;
    }

    public void setTwoWay(String twoWay) {
        this.two_way = twoWay;
    }

    @Override
    public String toString() {
        return "FollowRelation{" +
                "id=" + id +
                ", userid=" + userid +
                ", followid=" + followid +
                ", twoWay='" + two_way + '\'' +
                '}';
    }
}
