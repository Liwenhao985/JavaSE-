package douyin.entity;

public class Hot {
    private int id;
    private int likes;
    private int collection;
    private int frequency;

    public Hot(int id,int likes, int collection, int frequency) {
        this.likes = likes;
        this.collection = collection;
        this.frequency = frequency;
    }

    public int getId() {
        return id;
    }

    public int getLikes() {
        return likes;
    }

    public int getCollection() {
        return collection;
    }

    public int getFrequency() {
        return frequency;
    }

    @Override
    public String toString() {
        return "Hot{" +
                "id=" + id +
                ", likes=" + likes +
                ", collection=" + collection +
                ", frequency=" + frequency +
                '}';
    }
}
