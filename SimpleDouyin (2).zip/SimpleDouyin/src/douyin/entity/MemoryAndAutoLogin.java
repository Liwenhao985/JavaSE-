package douyin.entity;

public class MemoryAndAutoLogin {
    private int id;
    private String phone;
    private String password;
    private int auto;

    public MemoryAndAutoLogin(String phone, String password, int auto) {
        this.phone = phone;
        this.password = password;
        this.auto = auto;
    }

    public MemoryAndAutoLogin() {
    }

    public int getId() {
        return id;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getAuto() {
        return auto;
    }

    public void setAuto(int auto) {
        this.auto = auto;
    }

    @Override
    public String toString() {
        return "MemoryAndAutoLogin{" +
                "phone='" + phone + '\'' +
                ", password='" + password + '\'' +
                ", auto=" + auto +
                '}';
    }
}
