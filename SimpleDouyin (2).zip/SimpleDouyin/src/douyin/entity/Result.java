package douyin.entity;

public class Result {
    private int code;//状态码：0失败，1成功
    private String message;//提示信息
    private Object data;//返回数据

    private static final int OK=1;
    private static final int FAIL=0;
    private static final String OK_MESSAGE="OK";

    public Result(int code, String message, Object data) {
        this.code = code;
        this.message = message;
        this.data = data;
    }

    public static Result ok(Object data){
        return new Result(OK,OK_MESSAGE,data);
    }

    public static Result ok(){
        return new Result(OK,OK_MESSAGE,null);
    }

    public static Result fail(String message){
        return new Result(FAIL,message,null);
    }

    public int getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

    public Object getData() {
        return data;
    }

    public boolean isOK(){
        return code==OK;
    }
}
