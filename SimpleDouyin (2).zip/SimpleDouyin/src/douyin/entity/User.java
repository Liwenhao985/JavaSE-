package douyin.entity;

import java.util.Date;

public class User {
    private int id;//不能自己传
    private String name;
    private String phone;
    private String password;
    private String gender;
    private Date birthday;
    private String isShow;
    private String headPicture;
    private String introduction;//创建时非必需，所以构造里没放

    public User() {
    }

    public User(String name, String phone, String password, String gender, Date birthday,
                String isShow, String headPicture) {
        this.name = name;
        this.phone = phone;
        this.password = password;
        this.gender = gender;
        this.birthday = birthday;
        this.isShow = isShow;
        this.headPicture = headPicture;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    public String isShow() {
        return isShow;
    }

    public void setShow(String show) {
        isShow = show;
    }

    public String getHeadPicture() {
        return headPicture;
    }

    public void setHeadPicture(String headPicture) {
        this.headPicture = headPicture;
    }

    public String getIntroduction() {
        return introduction;
    }

    public void setIntroduction(String introduction) {
        this.introduction = introduction;
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", phone='" + phone + '\'' +
                ", password='" + password + '\'' +
                ", gender=" + gender +
                ", birthday=" + birthday +
                ", isShow=" + isShow +
                ", headPicture='" + headPicture + '\'' +
                ", introduction='" + introduction + '\'' +
                '}';
    }
}
