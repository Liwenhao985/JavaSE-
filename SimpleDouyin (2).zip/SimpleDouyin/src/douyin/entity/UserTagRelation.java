package douyin.entity;

public class UserTagRelation {
    private int userid;
    private int tagid;
    private double weight=0;

    public UserTagRelation() {
    }

    public UserTagRelation(int userid, int tagid) {
        this.userid = userid;
        this.tagid = tagid;
    }

    public int getUserid() {
        return userid;
    }

    public void setUserid(int userid) {
        this.userid = userid;
    }

    public int getTagid() {
        return tagid;
    }

    public void setTagid(int tagid) {
        this.tagid = tagid;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    @Override
    public String toString() {
        return "UserTagRelation{" +
                "userid=" + userid +
                ", tagid=" + tagid +
                ", weight=" + weight +
                '}';
    }
}
