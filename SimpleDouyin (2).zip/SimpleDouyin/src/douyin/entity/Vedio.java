package douyin.entity;

public class Vedio {
    private int id;
    private int userid;
    private String path;
    private String name;
    private int tagid;
    private String isShow;
    private String isLegal;
    private String cause;
    private String introduction;

    public Vedio() {
    }

    public Vedio(int userid, String path, String name, int tagid, String isShow, String introduction) {
        this.userid = userid;
        this.path = path;
        this.name = name;
        this.tagid = tagid;
        this.isShow = isShow;
        this.introduction = introduction;
    }

    public int getId() {
        return id;
    }

    public String getIsLegal() {
        return isLegal;
    }

    public String getCause() {
        return cause;
    }

    public int getUserid() {
        return userid;
    }

    public void setUserid(int userid) {
        this.userid = userid;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getTagId() {
        return tagid;
    }

    public void setTag(int tagid) {
        this.tagid = tagid;
    }

    public String getIsShow() {
        return isShow;
    }

    public void setIsShow(String isShow) {
        this.isShow = isShow;
    }

    public String getIntroduction() {
        return introduction;
    }

    public void setIntroduction(String introduction) {
        this.introduction = introduction;
    }

    @Override
    public String toString() {
        return "Vedio{" +
                "id=" + id +
                ", userid=" + userid +
                ", path='" + path + '\'' +
                ", name='" + name + '\'' +
                ", tagid='" + tagid + '\'' +
                ", isShow='" + isShow + '\'' +
                ", isLegal='" + isLegal + '\'' +
                ", cause='" + cause + '\'' +
                ", introduction='" + introduction + '\'' +
                '}';
    }

}
