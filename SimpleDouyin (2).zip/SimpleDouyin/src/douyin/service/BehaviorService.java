package douyin.service;

import douyin.entity.Result;

import java.time.Duration;
import java.time.LocalDateTime;

public interface BehaviorService {
    static boolean isEmpty(String str) {
        return str == null || str.isBlank();
    }

    Result addBehavior(int userId, int followId, String type, LocalDateTime time);

    Result deleteBehavior(int userId,  int vedioId,String type);
}
