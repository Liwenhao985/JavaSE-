package douyin.service;

import douyin.entity.Comment;
import douyin.entity.Result;

import java.time.LocalDateTime;
import java.util.ArrayList;

public interface CommentService {
    Result addNormalComment(int userId, int vedioId, String content, LocalDateTime time);

    Result review(int userId, int vedioId, int parentId, String content, LocalDateTime time);

    Result deleteComment(int id, int userId);

    ArrayList<Comment> getParentCommentByVedioId(int vedioId);

    ArrayList<Comment> getKidCommentByParentId(int parentId);
}
