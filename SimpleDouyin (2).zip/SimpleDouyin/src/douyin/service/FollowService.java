package douyin.service;

import douyin.entity.Result;

import java.util.ArrayList;

public interface FollowService {
    Boolean addFollowRelation(int userId, int followId);

    Result deleteFollowRelation(int userId, int followId);


    ArrayList<Integer> getFollowIdByUserId(int userId);
    ArrayList<Integer> getUserIdByFollowId(int userId);

    Result updateTwoWay(int userId, int followId);
    Result deleteTwoWay(int userId, int followId);

    Boolean queryIsFollow(int userId, int followId);
}
