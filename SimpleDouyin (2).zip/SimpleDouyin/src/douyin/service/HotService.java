package douyin.service;

import java.util.ArrayList;

public interface HotService {
    public boolean addHot();

    public boolean addLikes(int vedioId);
    public boolean addCollection(int vedioId);
    public boolean addFrequency(int vedioId);

    public boolean cutLikes(int vedioId);
    public boolean cutCollection(int vedioId);

    public int getLikes(int vedioId);
    public int getCollection(int vedioId);
    public int getFrequency(int vedioId);

    public ArrayList<String> getTop25();
    public ArrayList<String> getTop25ByLikes();
    public ArrayList<String> getTop25ByFrequency();
}
