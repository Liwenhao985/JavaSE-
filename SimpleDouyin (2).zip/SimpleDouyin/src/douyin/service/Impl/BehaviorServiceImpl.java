package douyin.service.Impl;

import douyin.dao.BehaviorDAO;
import douyin.dao.impl.BehaviorDAOImpl;
import douyin.entity.Result;
import douyin.service.BehaviorService;
import douyin.service.FollowService;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;

public class BehaviorServiceImpl implements BehaviorService {
    private FollowService followService = new FollowServiceImpl();
    private BehaviorDAO behaviorDAO = new BehaviorDAOImpl();
    private boolean isSuccess;

    @Override
    public Result addBehavior(int userId, int followId, String type, LocalDateTime time) {
        if (isEmpty(type)) {
            return Result.fail("type不能为空");
        }
        try{
            if (type.equals("关注")) {
                isSuccess = behaviorDAO.addBehavior(userId, followId, type, time);
                if(!isSuccess){
                    return Result.fail("添加行为失败");
                }
                isSuccess = followService.addFollowRelation(userId, followId);
                if(!isSuccess){
                    return Result.fail("添加行为成功，关注失败");
                }
                boolean result= followService.queryIsFollow(followId, userId);
                if(result&&isSuccess){
                    Result updateTwoWay1 = followService.updateTwoWay(followId, userId);
                    Result updateTwoWay2 = followService.updateTwoWay(userId, followId);
                    if (updateTwoWay1.isOK() && updateTwoWay2.isOK()) {
                        return Result.ok("添加行为成功，关注成功，交友成功");
                    } else {
                        return Result.fail("添加行为成功，关注成功，交友失败1");
                    }
                }
                return Result.fail("添加行为成功，关注成功，交友失败2");
            }else{
                isSuccess = behaviorDAO.addBehavior(userId, followId, type, time);
                try{
                    if(isSuccess){
                        return Result.ok("添加行为成功");
                    }else{
                        return Result.fail("添加行为失败");
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    return Result.fail("服务器出错");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return Result.fail("服务器出错");
        }
    }

    @Override
    public Result deleteBehavior(int userId,  int vedioId, String type) {
        try{
            isSuccess = behaviorDAO.deleteBehavior(userId, vedioId,type);
            try{
                if(isSuccess){
                    return Result.ok("删除行为成功");
                }else{
                    return Result.fail("删除行为失败");
                }
            } catch (Exception e) {
                e.printStackTrace();
                return Result.fail("服务器出错");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return Result.fail("服务器出错");
        }
    }

    public static boolean isEmpty(String str) {
        return str == null || str.isEmpty();
    }
}
