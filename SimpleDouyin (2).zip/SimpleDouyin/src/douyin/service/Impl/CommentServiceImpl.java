package douyin.service.Impl;

import douyin.dao.CommentDAO;
import douyin.dao.impl.CommentDAOImpl;
import douyin.entity.Comment;
import douyin.entity.Result;
import douyin.service.CommentService;

import java.time.LocalDateTime;
import java.util.ArrayList;

public class CommentServiceImpl implements CommentService {
    private CommentDAO commentDAO=new CommentDAOImpl();
    private boolean isSuccess;

    @Override
    public Result addNormalComment(int userId, int vedioId, String content, LocalDateTime time) {
        if(isEmpty(content)){
            return Result.fail("评论内容不能为空");
        }
        try {
            isSuccess=commentDAO.addNormalComment(userId,vedioId,content,time);
            if(isSuccess){
                return Result.ok("评论已发布");
            }else{
                return Result.fail("评论发布失败");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return Result.fail("服务器错误");
        }
    }

    @Override
    public Result review(int userId, int vedioId, int parentId, String content, LocalDateTime time) {
        if(isEmpty(content)){
            return Result.fail("评论内容不能为空");
        }
        try {
            isSuccess=commentDAO.review(userId,vedioId,parentId,content,time);
            if(isSuccess){
                return Result.ok("评论已发布");
            }else{
                return Result.fail("评论发布失败");
            }
        } catch (Exception e){
            e.printStackTrace();
            return Result.fail("服务器错误");
        }
    }

    @Override
    public Result deleteComment(int id,  int userId) {
        try {
            isSuccess=commentDAO.deleteComment(id,userId);
            if(isSuccess){
                return Result.ok("删除成功");
            }else{
                return Result.fail("删除失败");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return Result.fail("服务器错误");
        }
    }

    @Override
    public ArrayList<Comment> getParentCommentByVedioId(int vedioId) {
        try {
            ArrayList<Comment> parentComment=commentDAO.getParentCommentByVedioId(vedioId);
            if(parentComment!=null){
                return parentComment;
            }else{
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    @Override
    public ArrayList<Comment> getKidCommentByParentId(int parentId) {
        try {
            ArrayList<Comment> kidComment=commentDAO.getKidCommentByParentId(parentId);
            if(kidComment!=null){
                return kidComment;
            }else{
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private static boolean isEmpty(String str) {
        return str== null || str.isBlank();
    }
}
