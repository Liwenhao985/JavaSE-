package douyin.service.Impl;

import douyin.dao.FollowRelationDAO;
import douyin.dao.impl.FollowRelationDAOImpl;
import douyin.entity.Result;
import douyin.service.FollowService;

import java.util.ArrayList;

public class FollowServiceImpl implements FollowService {
    private FollowRelationDAO followDAO = new FollowRelationDAOImpl();
    private boolean isSuccess;

    @Override
    public Boolean addFollowRelation(int userId, int followId) {
        try{
            if(queryIsFollow(userId, followId)){
                return false;
            }
            isSuccess = followDAO.addFollowRelation(userId, followId);
            if (isSuccess) {
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public Result deleteFollowRelation(int userId, int followId) {
        try{
            isSuccess = followDAO.deleteFollowRelation(userId, followId);
            if (isSuccess) {
                return Result.ok();
            } else {
                return Result.fail("取消关注失败");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return Result.fail("服务器出错");
        }
    }

    @Override
    public Result updateTwoWay(int userId, int followId) {
        try{
            isSuccess = followDAO.updateTwoWay(userId, followId);
            if (isSuccess) {
                return Result.ok();
            } else {
                return Result.fail("更新失败");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return Result.fail("服务器出错");
        }
    }
    @Override
    public Result deleteTwoWay(int userId, int followId) {
        try{
            isSuccess = followDAO.deleteTwoWay(userId, followId);
            if (isSuccess) {
                return Result.ok();
            } else {
                return Result.fail("更新失败");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return Result.fail("服务器出错");
        }
    }

    @Override
    public Boolean queryIsFollow(int userId, int followId) {
        try{
            isSuccess= followDAO.queryIsFollow(userId, followId);
            if (isSuccess) {
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public ArrayList<Integer> getFollowIdByUserId(int userId) {
        try{
            return followDAO.getFollowIdByUserId(userId);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public ArrayList<Integer> getUserIdByFollowId(int userId) {
        try{
            return followDAO.getUserIdByFollowId(userId);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
