package douyin.service.Impl;

import douyin.dao.BaseDAO;
import douyin.dao.HotDAO;
import douyin.dao.VedioDAO;
import douyin.dao.impl.HotDAOImpl;
import douyin.dao.impl.VedioDAOImpl;
import douyin.entity.Hot;
import douyin.service.HotService;

import java.util.ArrayList;

public class HotServiceImpl implements HotService {
    private HotDAO hotDAO=new HotDAOImpl();
    private VedioDAO vedioDAO=new VedioDAOImpl();
    @Override
    public boolean addHot() {
        try{
            return hotDAO.addHot();
        }catch (Exception e){
            throw new RuntimeException(e);
        }
    }

    @Override
    public boolean addLikes(int vedioId) {
        try{
            return hotDAO.addLikes(vedioId);
        }catch (Exception e){
            throw new RuntimeException(e);
        }
    }
    @Override
    public boolean addCollection(int vedioId) {
        try{
            return hotDAO.addCollection(vedioId);
        }catch (Exception e){
            throw new RuntimeException(e);
        }
    }
    @Override
    public boolean addFrequency(int vedioId) {
        try{
            return hotDAO.addFrequency(vedioId);
        }catch (Exception e){
            throw new RuntimeException(e);
        }
    }

    @Override
    public boolean cutLikes(int vedioId) {
        try{
            return hotDAO.cutLikes(vedioId);
        }catch (Exception e){
            throw new RuntimeException(e);
        }
    }
    @Override
    public boolean cutCollection(int vedioId) {
        try{
            return hotDAO.cutCollection(vedioId);
        }catch (Exception e){
            throw new RuntimeException(e);
        }
    }

    @Override
    public int getLikes(int vedioId) {
        try{
            return hotDAO.getLikes(vedioId);
        }catch (Exception e){
            throw new RuntimeException(e);
        }
    }
    @Override
    public int getCollection(int vedioId) {
        try{
            return hotDAO.getCollection(vedioId);
        }catch (Exception e){
            throw new RuntimeException(e);
        }
    }
    @Override
    public int getFrequency(int vedioId) {
        try{
            return hotDAO.getFrequency(vedioId);
        }catch (Exception e){
            throw new RuntimeException(e);
        }
    }

    @Override
    public ArrayList<String> getTop25(){
        ArrayList<String> top25=new ArrayList<>();
        try{
            String sql="select * from hot order by (frequency+likes+collection) desc limit 25;";
            ArrayList<Integer> hotList=new BaseDAO().selectAll(Integer.class,sql);
            for (Integer hot:hotList){
                int id=hot;
                top25.add(vedioDAO.getVedioNameByVedioId(id));
            }
            return top25;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    @Override
    public ArrayList<String> getTop25ByLikes(){
        ArrayList<String> top25=new ArrayList<>();
        try{
            String sql="select * from hot order by likes desc limit 25;";
            ArrayList<Integer> hotList=new BaseDAO().selectAll(Integer.class,sql);
            for (Integer hot:hotList){
                int id=hot;
                top25.add(vedioDAO.getVedioNameByVedioId(id));
            }
            return top25;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    @Override
    public ArrayList<String> getTop25ByFrequency(){
        ArrayList<String> top25=new ArrayList<>();
        try{
            String sql="select * from hot order by frequency desc limit 25;";
            ArrayList<Integer> hotList=new BaseDAO().selectAll(Integer.class,sql);
            for (Integer hot:hotList){
                int id=hot;
                top25.add(vedioDAO.getVedioNameByVedioId(id));
            }
            return top25;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
