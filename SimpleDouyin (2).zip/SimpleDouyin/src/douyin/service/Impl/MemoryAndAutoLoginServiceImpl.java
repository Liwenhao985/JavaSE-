package douyin.service.Impl;

import douyin.dao.MemoryAndAutoLoginDAO;
import douyin.dao.impl.MemoryAndAutoLoginDAOImpl;
import douyin.service.MemoryAndAutoLoginService;

public class MemoryAndAutoLoginServiceImpl implements MemoryAndAutoLoginService {
    private MemoryAndAutoLoginDAO memoryAndAutoLoginDAO=new MemoryAndAutoLoginDAOImpl();

    @Override
    public boolean updateMemory(String phone, String password) {
        if(isEmpty(phone)||isEmpty(password)){
            return false;
        }
        try{
            return memoryAndAutoLoginDAO.update(phone, password);
        }catch (Exception e){
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean deleteMemoryAndAutoLogin() {
        try{
            return memoryAndAutoLoginDAO.delete();
        }catch (Exception e){
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean updateAuto(String phone, String password) {
        if(isEmpty(phone)||isEmpty(password)){
            return false;
        }
        try{
            return memoryAndAutoLoginDAO.updateAuto(phone, password);
        }catch (Exception e){
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public String getPhone() {
        int i= memoryAndAutoLoginDAO.getAuto();
        if(i==0){
            return null;
        }else if(i==1){
            try{
                return memoryAndAutoLoginDAO.getPhone();
            }catch (Exception e){
                e.printStackTrace();
                return null;
            }
        }
        return null;
    }

    @Override
    public String getPassword() {
        int i= memoryAndAutoLoginDAO.getAuto();
        if(i==0){
            return null;
        }else if(i==1){
            try{
                return memoryAndAutoLoginDAO.getPassword();
            }catch (Exception e){
                e.printStackTrace();
                return null;
            }
        }
        return null;
    }

    private static boolean isEmpty(String str) {
        return str== null || str.isBlank();
    }
}
