package douyin.service.Impl;

import douyin.entity.Result;
import douyin.service.FollowService;
import douyin.service.PullVideosRecommendation;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class PullVideosRecommendationImpl implements PullVideosRecommendation {
    private ArrayList<String> list=new ArrayList<>();
    private int p=0;
    @Override
    public ArrayList<String> pullVideosRecommendation(int userId) {
        FollowService followService=new FollowServiceImpl();
        ArrayList<Integer> followIdList=followService.getFollowIdByUserId(userId);
        for (Integer followId : followIdList) {
            ArrayList<String> vedioPathList=new VedioServiceImpl().getVedioPathByUserId(followId);
            //每次每个关注的作者的推荐视频，每次取5个，每次取完一个作者的推荐视频，p加5，保证每次推荐视频不重复
            for(int i=vedioPathList.size()-1-p ; i>=(vedioPathList.size()-5-p) && i>=0;i--){
                list.add(vedioPathList.get(i));
            }
        }
        //p记录已经取了的视频数量，之后从下标p开始取，防止重复
        p+=5;
        //根据发布时间排序
        Collections.sort(list, new Comparator<String>() {
            @Override
            public int compare(String o1, String o2) {
                int num1=new VedioServiceImpl().getVedioIdByPath(o1);
                int num2=new VedioServiceImpl().getVedioIdByPath(o2);
                return num1-num2;
            }
        });
        return list;
    }

    @Override
    public ArrayList<String> append(int userId) {
        list.clear();
        return pullVideosRecommendation(userId);
    }
}
