package douyin.service.Impl;

import douyin.dao.VedioDAO;
import douyin.dao.impl.VedioDAOImpl;
import douyin.service.PushVideosRecommendation;
import douyin.service.TagService;
import douyin.service.UserTagRelationService;
import douyin.service.VedioService;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class PushVideosRecommendationImpl implements PushVideosRecommendation {
    private ArrayList<String> list = new ArrayList<>();
    private VedioService vedioService = new VedioServiceImpl();
    /**
     * 根据用户ID推送视频推荐列表
     * 该方法首先根据用户的标签关系获取推荐视频，然后根据用户对不同标签的偏好权重来确定推荐数量，
     * 最后通过随机标签补充推荐列表，直到推荐列表达到预定数量,同时削减“信息茧房”现象
     *
     * @param userId 用户ID，用于获取用户相关的标签和权重信息
     * @return 返回一个包含视频路径的ArrayList，作为推荐列表
     */
    @Override
    public ArrayList<String> pushVideosRecommendation(int userId) {
        // 获取用户关联的标签ID列表
        ArrayList<Integer> tagIdList =new UserTagRelationServiceImpl().getTagIdByUserId(userId);
        // 计算用户所有标签权重的总和
        int weightSum = cauclateWeightSum(userId);
        // 遍历每个标签ID，获取相应的视频路径列表
        for (Integer tagId : tagIdList) {
            ArrayList<String> vedioPathList = vedioService.getVedioPathByTagId(tagId);
            // 获取用户对当前标签的权重
            int weight = new UserTagRelationServiceImpl().getWeight(userId, tagId);
            // 根据权重和权重总和，计算出当前标签应推荐的视频数量，总共不超过40个
            int count = (int) Math.ceil(weight * 40.0 / weightSum);
            // 从当前标签的视频路径列表中，按计算出的数量添加视频到推荐列表
            for(int i=vedioPathList.size()-1;i>=(vedioPathList.size()-count)&&i>=0;i--){
                list.add(vedioPathList.get(i));
            }
        }
        // 记录目前推荐列表大小变量
        int num=list.size();
        // 如果推荐列表数量不足50，通过随机选择标签补充推荐列表
        while(num<50){
            // 根据已有标签数量，随机生成一个标签ID
            int tagId = (int) (Math.random() * TagServiceImpl.getSumOfTag())+1;
            // 确保随机选择的标签不在已处理的标签列表中
            if(!tagIdList.contains(tagId)){
                ArrayList<String> vedioPathList = vedioService.getVedioPathByTagId(tagId);
                // 从随机标签的视频路径列表中添加视频到推荐列表，直到列表达到50个或该标签的视频添加完毕
                for(int i=vedioPathList.size()-1;i>=(vedioPathList.size()-4)&&num<50;i--){
                    list.add(vedioPathList.get(i));
                    num++;
                }
            }
            //一定不能漏，否则若用户与所有tag建立联系后会死循环
            num++;
        }
        // 打乱推荐列表的顺序，以增加多样性
        Collections.shuffle(list);
        // 返回最终的推荐列表
        return list;
    }

    @Override
    public ArrayList<String> pushVideosRecommendation2(int userId) {
        // 获取用户关联的标签ID列表
        ArrayList<Integer> tagIdList =new UserTagRelationServiceImpl().getTagIdByUserId(userId);
        // 计算用户所有标签权重的总和
        int weightSum = cauclateWeightSum(userId);

        // 遍历每个标签ID，获取相应的视频路径列表
        for (Integer tagId : tagIdList) {
            ArrayList<String> vedioPathList = vedioService.getVedioPathByTagId(tagId);
            // 获取用户对当前标签的权重
            int weight = new UserTagRelationServiceImpl().getWeight(userId, tagId);
            // 根据权重和权重总和，计算出当前标签应推荐的视频数量
            int count = (int) Math.ceil(weight * 32.0 / weightSum);

            // 从当前标签的视频路径列表中，按计算出的数量添加视频到推荐列表
            for(int i=vedioPathList.size()-1;i>=(vedioPathList.size()-count)&&i>=0;i--){
                list.add(vedioPathList.get(i));
            }
        }

        // 初始化推荐列表大小变量
        int numOfList=list.size();
        // 如果推荐列表数量不足40，通过随机选择标签补充推荐列表
        while(numOfList<40){
            // 随机生成一个标签ID
            int tagId = (int) (Math.random() * TagServiceImpl.getSumOfTag())+1;
            // 确保随机选择的标签不在已处理的标签列表中
            if(!tagIdList.contains(tagId)){
                ArrayList<String> vedioPathList = vedioService.getVedioPathByTagId(tagId);
                // 从随机标签的视频路径列表中添加视频到推荐列表，直到列表达到50个或该标签的视频添加完毕
                for(int i=vedioPathList.size()-1 ; i>=(vedioPathList.size()-4) && numOfList<40 ; i--){
                    list.add(vedioPathList.get(i));
                    numOfList++;
                }
            }
            // 一定不能漏，否则若用户与所有tag建立联系后会死循环
            numOfList++;
        }

        // 打乱推荐列表的顺序，以增加多样性
        Collections.shuffle(list);
        // 返回最终的推荐列表
        return list;
    }

    @Override
    public ArrayList<String> append(int userId) {
        //把原先的list清空，防止影响
        list.clear();
        return pushVideosRecommendation2(userId);
    }

    private int cauclateWeightSum(int userId){
        int sum=0;
        for (Integer integer : new UserTagRelationServiceImpl().getTagIdByUserId(userId)) {
            sum+=new UserTagRelationServiceImpl().getWeight(userId, integer);
        }
        return sum;
    }
}
