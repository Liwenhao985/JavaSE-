package douyin.service.Impl;

import douyin.dao.TagDAO;
import douyin.dao.impl.TagDAOImpl;
import douyin.entity.Result;
import douyin.service.TagService;

public class TagServiceImpl implements TagService {
    private static TagDAO tagDAO=new TagDAOImpl();
    private boolean isSuccess;

    @Override
    public Result addTag(String name) {
        if(isEmpty(name)){
            return Result.fail("标签名不能为空");
        }
        try {
            isSuccess = tagDAO.addTag(name);
            if(isSuccess){
                return Result.ok();
            }else{
                return Result.fail("添加标签失败");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return Result.fail("服务器出错");
        }
    }

    @Override
    public Result deleteTag(int id) {
        try {
            isSuccess = tagDAO.deleteTag(id);
            if(isSuccess){
                return Result.ok();
            }else{
                return Result.fail("删除标签失败");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return Result.fail("服务器出错");
        }
    }

    @Override
    public Result getTagIdByName(String name) {
        if(isEmpty(name)){
            return Result.fail("标签名不能为空");
        }
        try {
            int id = tagDAO.getIdByName(name);
            if(id != 0){
                return Result.ok(id);
            }else{
                return Result.fail("标签不存在");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return Result.fail("服务器出错");
        }
    }

    public static int getSumOfTag() {
        try {
            return tagDAO.getNumOfTag();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    private static boolean isEmpty(String str) {
        return str== null || str.isBlank();
    }
}
