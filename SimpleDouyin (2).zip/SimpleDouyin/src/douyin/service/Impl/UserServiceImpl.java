package douyin.service.Impl;

import douyin.dao.UserDAO;
import douyin.dao.impl.UserDAOImpl;
import douyin.entity.Result;
import douyin.entity.User;
import douyin.service.UserService;

import java.util.Date;

public class UserServiceImpl implements UserService {
    private UserDAO userDAO = new UserDAOImpl();
    private boolean isSuccess;
    
    @Override
    public Result login(String phone, String password) {
        if(isEmpty(phone)){
            return Result.fail("账号不能为空");
        }
        if(isEmpty(password)){
            return Result.fail("密码不能为空");
        }
        if(phone.length() != 11){
            return Result.fail("手机号格式错误");
        }
        
        try {
            User user = userDAO.login(phone, password);
            if(user == null){
                return Result.fail("账号或密码错误");
            }
            return Result.ok(user);
        } catch (Exception e) {
            e.printStackTrace();
            return Result.fail("服务器错误");
        }
    }
    
    @Override
    public Result register(String name, String password, String phone, Date birthday, String gender, String isShow, String headPicture) throws Exception {
        if(isEmpty(name)){
            return Result.fail("用户名不能为空");
        }
        if(isEmpty(password)){
            return Result.fail("密码不能为空");
        }
        if(isEmpty(phone)){
            return Result.fail("手机号不能为空");
        }
        if(phone.length() != 11){
            return Result.fail("手机号格式错误");
        }
        if(birthday==null){
            return Result.fail("生日不能为空");
        }
        if(isEmpty(gender)){
            return Result.fail("性别不能为空");
        }
        if(isEmpty(headPicture)){
            return Result.fail("头像不能为空");
        }

        try{
            isSuccess= userDAO.register(name, password, phone,birthday, gender, isShow, headPicture);
            if(isSuccess){
                return Result.ok();
            }else{
                return Result.fail("注册失败");
            }
        }catch (Exception e){
            e.printStackTrace();
            return Result.fail("服务器错误");
        }
    }

    @Override
    public Result updateName(User user, String name) {
        if(isEmpty(name)){
            return Result.fail("用户名不能为空");
        }
        try {
            isSuccess = userDAO.updateName(user, name);
            if(isSuccess){
                return Result.ok();
            }else{
                return Result.fail("更新失败");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return Result.fail("服务器错误");
        }
    }
    @Override
    public Result updatePassword(User user, String password) {
        if(isEmpty(password)){
            return Result.fail("密码不能为空");
        }
        try {
            isSuccess = userDAO.updatePassword(user, password);
            if(isSuccess){
                return Result.ok();
            }else{
                return Result.fail("更新失败");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return Result.fail("服务器错误");
        }
    }
    @Override
    public Result updateBirthday(User user, Date birthday) {
        if(birthday==null){
            return Result.fail("生日不能为空");
        }
        try {
            isSuccess = userDAO.updateBirthday(user, birthday);
            if(isSuccess){
                return Result.ok();
            }else{
                return Result.fail("更新失败");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return Result.fail("服务器错误");
        }
    }
    @Override
    public Result updateGender(User user, String gender) {
        if(isEmpty(gender)){
            return Result.fail("性别不能为空");
        }
        try {
            isSuccess = userDAO.updateGender(user, gender);
            if(isSuccess){
                return Result.ok();
            }else{
                return Result.fail("更新失败");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return Result.fail("服务器错误");
        }
    }
    @Override
    public Result updateIntroduction(User user, String introduction) {
        if(isEmpty(introduction)){
            return Result.fail("简介不能为空");
        }
        try {
            isSuccess = userDAO.updateIntroduction(user, introduction);
            if(isSuccess){
                return Result.ok();
            }else{
                return Result.fail("更新失败");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return Result.fail("服务器错误");
        }
    }
    @Override
    public Result updateHeadPicture(User user, String headPicture) {
        if(isEmpty(headPicture)){
            return Result.fail("头像不能为空");
        }
        try {
            isSuccess = userDAO.updateHeadPicture(user, headPicture);
            if(isSuccess){
                return Result.ok();
            }else{
                return Result.fail("更新失败");
            }
        } catch (Exception e) {
            e.printStackTrace();
           return Result.fail("服务器错误");
        }
    }
    @Override
    public Result updateIsShow(User user, String isShow) {
        if(isEmpty(isShow)){
            return Result.fail("是否展示不能为空");
        }
        try {
            isSuccess = userDAO.updateIsShow(user, isShow);
            if(isSuccess){
                return Result.ok();
            }else{
                return Result.fail("更新失败");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return Result.fail("服务器错误");
        }
    }

    private static boolean isEmpty(String str) {
        return str== null || str.isBlank();
    }
}
