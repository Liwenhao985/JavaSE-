package douyin.service.Impl;

import douyin.dao.UseTagRelationDAO;
import douyin.dao.impl.UserTagRelationDAOImpl;
import douyin.entity.Result;
import douyin.service.UserTagRelationService;

import java.util.ArrayList;

public class UserTagRelationServiceImpl implements UserTagRelationService {
    private UseTagRelationDAO useTagRelationDAO = new UserTagRelationDAOImpl();
    private boolean isSuccess;

    @Override
    public Result addUseTagRelation(int userId, int tagId) {
        try{
            isSuccess = useTagRelationDAO.addUseTagRelation(userId, tagId);
            if (isSuccess) {
                return Result.ok();
            } else {
                return Result.fail("更新失败");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return Result.fail("服务器错误");
        }
    }

    @Override
    public Result deleteUseTagRelation(int userId, int tagId) {
        try{
            isSuccess = useTagRelationDAO.deleteUseTagRelation(userId, tagId);
            if (isSuccess) {
                return Result.ok();
            } else {
                return Result.fail("更新失败");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return Result.fail("服务器错误");
        }
    }

    @Override
    public Result addWeight(int userId, int tagId) {
        try{
            isSuccess = useTagRelationDAO.addWeight(userId, tagId);
            if (isSuccess) {
                return Result.ok();
            } else {
                return Result.fail("更新失败");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return Result.fail("服务器错误");
        }
    }

    @Override
    public Result cutWeight(int userId, int tagId) {
        try{
            isSuccess = useTagRelationDAO.cutWeight(userId, tagId);
            if (isSuccess) {
                return Result.ok();
            } else {
                return Result.fail("更新失败");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return Result.fail("服务器错误");
        }
    }

    @Override
    public ArrayList<Integer> getTagIdByUserId(int userId) {
        try{
            ArrayList<Integer> tagIdList = useTagRelationDAO.getTagIdByUserId(userId);
            if (tagIdList != null) {
                return tagIdList;
            } else {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public Integer getWeight(int userId, int tagId) {
        try{
            Integer weight = useTagRelationDAO.getWeight(userId, tagId);
            if (weight != null) {
                return weight;
            } else {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    private static boolean isEmpty(String str) {
        return str== null || str.isBlank();
    }
}
