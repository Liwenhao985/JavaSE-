package douyin.service.Impl;

import douyin.dao.VedioDAO;
import douyin.dao.impl.VedioDAOImpl;
import douyin.entity.Result;
import douyin.service.VedioService;

import java.util.ArrayList;

public class VedioServiceImpl implements VedioService {
    private VedioDAO vedioDAO = new VedioDAOImpl();
    private boolean isSuccess;

    @Override
    public Result addVedio(int userId, String path, String name, int tagid, String isShow, String introduction) {
        if (isEmpty(path) || isEmpty(name) || isEmpty(isShow)) {
            return Result.fail("信息不能为空");
        }
        isSuccess = vedioDAO.addVedio(userId, path, name, tagid, isShow, introduction);
        if (isSuccess) {
            return Result.ok();
        } else {
            return Result.fail("上传失败");
        }
    }

    @Override
    public Result deleteVedio(int id) {
        try{
            isSuccess = vedioDAO.deleteVedio(id);
            if (isSuccess) {
                return Result.ok();
            } else {
                return Result.fail("删除失败");
            }
        }catch (Exception e){
            e.printStackTrace();
            return Result.fail("服务器出错");
        }
    }
    @Override
    public ArrayList<String> getVedioPathByTagId(int tagId) {
        try{
            ArrayList<String> paths = vedioDAO.getVedioPathByTagId(tagId);
            if (paths != null) {
                return paths;
            } else {
                return null;
            }
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }
    @Override
    public int getVedioIdByPath(String path) {
        try{
            int vedioId = vedioDAO.getVedioIdByPath(path);
            if (vedioId != 0) {
                return vedioId;
            } else {
                return 0;
            }
        }catch (Exception e){
            e.printStackTrace();
            return 0;
        }
    }
    @Override
    public int getTagIdByVedioId(int vedioId) {
        try{
            int tagId = vedioDAO.getTagIdByVedioId(vedioId);
            if (tagId != 0) {
                return tagId;
            } else {
                return 0;
            }
        }catch (Exception e){
            e.printStackTrace();
            return 0;
        }
    }
    @Override
    public int getUserIdByVedioPath(String path) {
        try{
            int userId = vedioDAO.getUserIdByVedioPath(path);
            if (userId != 0) {
                return userId;
            } else {
                return 0;
            }
        }catch (Exception e){
            e.printStackTrace();
            return 0;
        }
    }
    @Override
    public ArrayList<String> getVedioPathByUserId(int userId) {
        try{
            ArrayList<String> paths = vedioDAO.getVedioPathByUserId(userId);
            if (paths != null) {
                return paths;
            } else {
                return null;
            }
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public Result updateIsLegal(int id, String isLegal) {
        try{
            isSuccess = vedioDAO.updateIsLegal(id, isLegal);
            if (isSuccess) {
                return Result.ok();
            } else {
                return Result.fail("更新失败");
            }
        }catch (Exception e){
            e.printStackTrace();
            return Result.fail("服务器出错");
        }
    }
    @Override
    public Result updateIntroduction(int id, String introduction) {
        try{
            isSuccess = vedioDAO.updateIntroduction(id, introduction);
            if (isSuccess) {
                return Result.ok();
            } else {
                return Result.fail("更新失败");
            }
        }catch (Exception e){
            e.printStackTrace();
            return Result.fail("服务器出错");
        }
    }
    @Override
    public Result updateIsShow(int id, String ifShow) {
        try{
            isSuccess = vedioDAO.updateIsShow(id, ifShow);
            if (isSuccess) {
                return Result.ok();
            } else {
                return Result.fail("更新失败");
            }
        }catch (Exception e){
            e.printStackTrace();
            return Result.fail("服务器出错");
        }
    }
    @Override
    public Result updateCause(int id, String cause) {
        try{
            isSuccess = vedioDAO.updateCause(id, cause);
            if (isSuccess) {
                return Result.ok();
            } else {
                return Result.fail("更新失败");
            }
        }catch (Exception e){
            e.printStackTrace();
            return Result.fail("服务器出错");
        }
    }

    private static boolean isEmpty(String str) {
        return str== null || str.isBlank();
    }
}
