package douyin.service;

public interface MemoryAndAutoLoginService {
    public boolean updateMemory(String phone, String password);
    public boolean deleteMemoryAndAutoLogin();
    public boolean updateAuto(String phone, String password);
    public String getPhone();
    public String getPassword();
}
