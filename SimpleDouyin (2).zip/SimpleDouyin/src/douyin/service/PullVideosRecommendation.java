package douyin.service;

import java.util.ArrayList;

public interface PullVideosRecommendation {
    public ArrayList<String> pullVideosRecommendation(int userId);
    public ArrayList<String> append(int userId);
}
