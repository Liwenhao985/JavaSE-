package douyin.service;

import java.util.ArrayList;

public interface PushVideosRecommendation {
    public ArrayList<String> pushVideosRecommendation(int userId);
    public ArrayList<String> pushVideosRecommendation2(int userId);

    public ArrayList<String> append(int userId);
}
