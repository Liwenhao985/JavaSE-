package douyin.service;

import douyin.entity.Result;

public interface TagService {
    Result addTag(String name);

    Result deleteTag(int id);

    Result getTagIdByName(String name);
}
