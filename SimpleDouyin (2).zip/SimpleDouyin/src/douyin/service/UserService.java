package douyin.service;

import douyin.entity.Result;
import douyin.entity.User;

import java.util.Date;

public interface UserService {
    Result login(String phone, String password);

    Result register(String name, String password, String phone, Date birthday, String gender, String isShow, String headPicture) throws Exception;

    Result updateName(User user, String name);

    Result updatePassword(User user, String password);

    Result updateBirthday(User user, Date birthday);

    Result updateGender(User user, String gender);

    Result updateIntroduction(User user, String introduction);

    Result updateHeadPicture(User user, String headPicture);

    Result updateIsShow(User user, String isShow);
}
