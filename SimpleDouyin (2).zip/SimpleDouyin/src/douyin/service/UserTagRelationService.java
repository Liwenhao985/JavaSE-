package douyin.service;

import douyin.entity.Result;

import java.util.ArrayList;

public interface UserTagRelationService {
    Result addUseTagRelation(int userId, int tagId);

    Result deleteUseTagRelation(int userId, int tagId);

    Result addWeight(int userId, int tagId);

    ArrayList<Integer> getTagIdByUserId(int userId);
    Integer getWeight(int userId, int tagId);

    Result cutWeight(int userId, int tagId);
}
