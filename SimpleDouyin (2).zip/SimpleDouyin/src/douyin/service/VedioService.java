package douyin.service;

import douyin.entity.Result;

import java.util.ArrayList;

public interface VedioService {
    Result addVedio(int userId, String path, String name, int tagid, String isShow, String introduction);

    Result deleteVedio(int id);

    ArrayList<String> getVedioPathByTagId(int tagId);
    int getVedioIdByPath(String path);
    int getTagIdByVedioId(int vedioId);
    int getUserIdByVedioPath(String path);
    ArrayList<String> getVedioPathByUserId(int userId);

    Result updateIsLegal(int id, String isLegal);
    Result updateIntroduction(int id, String introduction);
    Result updateIsShow(int id, String ifShow);
    Result updateCause(int id, String cause);
}
