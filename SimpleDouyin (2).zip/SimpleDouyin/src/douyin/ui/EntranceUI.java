package douyin.ui;

import douyin.entity.Result;
import douyin.entity.User;
import douyin.service.Impl.MemoryAndAutoLoginServiceImpl;
import douyin.service.Impl.UserServiceImpl;
import douyin.service.MemoryAndAutoLoginService;
import douyin.service.UserService;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class EntranceUI {
    private UserService userService = new UserServiceImpl();
    private MemoryAndAutoLoginService memoryAndAutoLoginService = new MemoryAndAutoLoginServiceImpl();
    private Scanner scanner = new Scanner(System.in);
    private SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");

    public User entranceUI() {
        User user=null;
        System.out.println("欢迎来到抖音");
        int choice = 0;
        while (true) {
            System.out.println("请选择数字：");
            System.out.println("1.登录");
            System.out.println("2.注册");
            System.out.println("3.退出");
            choice = scanner.nextInt();
            switch (choice){
                case 1->{
                    user = login();
                    if(user!=null){
                        System.out.println("登录成功,欢迎"+user.getName()+"回到这个大家庭");
                        System.out.println("------------------------------");
                        return user;
                    }
                }
                case 2->{
                    register();
                }
                case 3->{
                    System.out.println("再见！我们一定会再次相遇的！");
                    System.exit(0);
                }
                default -> {
                    System.out.println("输入错误,请重新输入");
                    System.out.println("------------------------------");
                }
            }
        }
    }

    private User login() {
        String phone;
        String password;
        System.out.print("请输入手机号：");
        //尝试从内存中获取，若记住密码则直接打印上去
        phone= memoryAndAutoLoginService.getPhone();
        if(phone==null){
            phone = scanner.next();
        }else{
            System.out.println(phone);
        }
        System.out.print("请输入密码：");
        //尝试从内存中获取，若记住密码则直接打印上去
        password= memoryAndAutoLoginService.getPassword();
        if(password==null){
            password = scanner.next();
        }else{
            System.out.println(password);
        }

        //选择是否保存密码
        extracted(phone, password);

        //登录检验
        try {
            Result result = userService.login(phone, password);
            User user = (User) result.getData();
            if(user == null){
                System.out.println("账号或密码错误");
                System.out.println("------------------------------");
                return null;
            }
            return user;
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("服务器错误,请稍后");
            return null;
        }
    }
    private void extracted(String phone, String password) {
        int choice = 0;
        while(choice!=1&&choice!=2){
            System.out.println("是否记住密码？");
            System.out.println("1.是");
            System.out.println("2.否");
            choice = scanner.nextInt();
            switch (choice){
                case 1->{
                    memoryAndAutoLoginService.updateMemory(phone, password);
                    memoryAndAutoLoginService.updateAuto(phone, password);
                }
                case 2->{
                    memoryAndAutoLoginService.deleteMemoryAndAutoLogin();
                }
                default -> {
                    System.out.println("输入有误,请重新输入");
                }
            }
        }
    }

    private void register() {
        String name;
        String password;
        String phone;
        String birthday2;
        Date birthday;
        String gender;
        String isShow;
        String headPicture;
        int choice = 0;
        while (true) {
            System.out.println("请选择数字：");
            System.out.println("1.注册");
            System.out.println("2.返回");
            choice = scanner.nextInt();
            switch (choice){
                case 1->{
                    name= getString("用户名：");
                    password= getString("密码：");
                    phone= getString("手机号：");
                    birthday2= getString("生日(请按“年-月-日”的格式)：");
                    gender= getString("性别：");
                    isShow= getString("是否展示：");
                    headPicture= getString("头像：");
                    // 将生日字符串转换为Date对象
                    try{
                        birthday = simpleDateFormat.parse(birthday2);
                    } catch (ParseException e) {
                        throw new RuntimeException(e);
                    }
                    //  判断输入是否为空
                    if(isEmpty(name)||isEmpty(password)||isEmpty(phone)||isEmpty(birthday2)||isEmpty(gender)||isEmpty(isShow)||isEmpty(headPicture)){
                        System.out.println("输入不能为空");
                        return;
                    }
                    //  注册
                    try {
                        //检验用户是否存在
                        User user= (User) userService.login(phone, password).getData();
                        if(user!=null){
                            System.out.println("用户已存在");
                            System.out.println("------------------------------");
                            continue;
                        }
                        // 不存在则注册
                        Result result = userService.register(name, password, phone, birthday, gender, isShow, headPicture);
                        if(result.isOK()){
                            System.out.println("注册成功");
                            return;
                        }else{
                            System.out.println("注册失败");
                            System.out.println("---------------------------");
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        System.out.println("服务器错误,请稍后");
                    }
                }
                case 2->{
                    System.out.println("返回成功");
                    System.out.println("------------------------------");
                    return;
                }
                default -> {
                    System.out.println("输入错误,请重新输入");
                    System.out.println("------------------------------");
                }
            }
        }
    }

    private String  getString(String message) {
        System.out.print("请输入"+message);
        return scanner.next();
    }

    private static boolean isEmpty(String str) {
        return str== null || str.isBlank();
    }
}
