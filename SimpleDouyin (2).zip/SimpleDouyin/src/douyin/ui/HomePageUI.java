package douyin.ui;

import douyin.entity.Result;
import douyin.entity.User;
import douyin.service.BehaviorService;
import douyin.service.FollowService;
import douyin.service.Impl.BehaviorServiceImpl;
import douyin.service.Impl.FollowServiceImpl;
import douyin.service.Impl.UserServiceImpl;
import douyin.service.Impl.VedioServiceImpl;
import douyin.service.UserService;
import douyin.service.VedioService;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class HomePageUI {
    private final UserService userService = new UserServiceImpl();
    private final FollowService followService = new FollowServiceImpl();
    private final VedioService vedioService = new VedioServiceImpl();
    private final Scanner sc = new Scanner(System.in);
    public String homePageUI(User user) throws Exception {
        int choice = 0;
        while(true){
            System.out.println("----------------------");
            showBasicMessage(user);
            System.out.println("----------------------");
            System.out.println("请选择数字:");
            System.out.println("1.编辑主页");
            System.out.println("2.查看首页");
            System.out.println("3.查看排行榜");
            System.out.println("4.退出登录");
            choice = sc.nextInt();

            switch (choice){
                case 1->{changeBasicMessage(user);}
                case 2->{return "查看首页";}
                case 3->{return "查看排行榜";}
                case 4->{
                    System.out.println("退出成功,希望还能与您再次相遇");
                    return "退出登录";
                }
                default -> {
                    System.out.println("输入错误,请重新输入");
                }
            }
        }
    }

    //信息展示
    private void showBasicMessage(User user){
        System.out.print(user.getHeadPicture()+"  ");
        System.out.println(user.getName());
        System.out.println("性别:"+user.getGender());
        System.out.println("生日:"+user.getBirthday());
        System.out.println("————————————————");
        follow(user);
        System.out.println("————————————————");
        System.out.println("个人介绍:"+user.getIntroduction());
        System.out.println("————————————————");
        vedioRelated(user);
    }
    private void follow(User user){
        ArrayList<Integer> followIdList = followService.getFollowIdByUserId(user.getId());
        System.out.print("关注:"+followIdList.size()+" ");
        ArrayList<Integer> userIdList = followService.getUserIdByFollowId(user.getId());
        System.out.print("粉丝:"+userIdList.size()+" ");
        System.out.println("互关:"+numOfTwoWay(followIdList,userIdList));
    }
    private void vedioRelated(User user){
        ArrayList<String> vedioPathList = vedioService.getVedioPathByUserId(user.getId());
        if(vedioPathList.isEmpty()){
            System.out.println("暂无作品");
        }else{
            System.out.println("作品:");
            for(String path:vedioPathList){
                System.out.println(path);
            }
        }
    }
    private int numOfTwoWay(ArrayList<Integer> a, ArrayList<Integer> b){
        int count = 0;
        for(Integer i:a){
            if(b.contains(i)){
                count++;
            }
        }
        return count;
    }

    //修改个人信息
    private void changeBasicMessage(User user) throws Exception {
        int choice = 0;
        while(true){
            System.out.println("----------------------");
            System.out.println("请选择数字:");
            System.out.println("1.修改昵称");
            System.out.println("2.修改密码");
            System.out.println("3.修改性别");
            System.out.println("4.修改生日");
            System.out.println("5.修改简介");
            System.out.println("6.修改头像");
            System.out.println("7.修改是否公开");
            System.out.println("8.保存并返回");
            choice = sc.nextInt();

            switch (choice){
                case 1->changeName(user);
                case 2->changePassword(user);
                case 3->changeGender(user);
                case 4->changeBirthday(user);
                case 5->changeIntroduction(user);
                case 6->changeHeadPicture(user);
                case 7->changeIsShow(user);
                case 8->{
                    System.out.println("返回成功");
                    return;
                }
                default -> {
                    System.out.println("输入错误,请重新输入");
                }
            }
        }
    }
    private void changeName(User user){
        String name;
        System.out.println("请输入新昵称:");
        name = sc.next();
        Result result = userService.updateName(user,name);
        System.out.println(result.getData());
    }
    private void changePassword(User user){
        String password;
        System.out.println("请输入新密码:");
        password = sc.next();
        Result result = userService.updatePassword(user,password);
        System.out.println(result.getData());
    }
    private void changeGender(User user){
        String gender;
        System.out.println("请输入性别:");
        gender = sc.next();
        Result result = userService.updateGender(user,gender);
        System.out.println(result.getData());
    }
    private void changeBirthday(User user) throws ParseException {
        String birthday;
        System.out.println("请输入生日（请按“年-月-日”的格式）:");
        birthday = sc.next();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date date = sdf.parse(birthday);
        Result result = userService.updateBirthday(user,date);
        System.out.println(result.getData());
    }
    private void changeIntroduction(User user){
        String introduction;
        System.out.println("请输入简介:");
        introduction = sc.next();
        Result result = userService.updateIntroduction(user,introduction);
        System.out.println(result.getData());
    }
    private void changeHeadPicture(User user){
        String headPicture;
        System.out.println("请上传新头像:");
        headPicture = sc.next();
        Result result = userService.updateHeadPicture(user,headPicture);
        System.out.println(result.getData());
    }
    private void changeIsShow(User user){
        String isShow;
        System.out.println("请输入是否公开:");
        System.out.println("0.否");
        System.out.println("1.是");
        isShow = sc.next();
        Result result = userService.updateIsShow(user,isShow);
        System.out.println(result.getData());
    }
}
