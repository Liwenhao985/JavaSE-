package douyin.ui;

import douyin.entity.User;
import douyin.service.HotService;
import douyin.service.Impl.HotServiceImpl;

import java.util.ArrayList;
import java.util.Scanner;

public class RankingUI {
    private final HotService hotService=new HotServiceImpl();
    private final Scanner sc=new Scanner(System.in);

    public String rankingUI(User user) throws Exception {
        int choice=0;
        while(true){
            System.out.println("---------------------------");
            System.out.println("请选择数字:");
            System.out.println("1.综合Top25");
            System.out.println("2.点赞数Top25");
            System.out.println("3.播放数Top25");
            System.out.println("4.查看首页");
            System.out.println("5.查看主页");
            System.out.println("6.退出登录");
            choice=sc.nextInt();

            switch (choice){
                case 1->{gainTop25();}
                case 2->{gainTop25ByLikes();}
                case 3->{gainTop25ByFrequency();}
                case 4->{return "查看首页";}
                case 5->{return "查看主页";}
                case 6->{
                    System.out.println("退出成功,希望还能与您再次相遇");
                    return "退出登录";
                }
                default -> {
                    System.out.println("输入有误,请重新输入");
                }
            }
        }
    }

    private void gainTop25() throws Exception {
    	ArrayList<String> top25=hotService.getTop25();
        System.out.println("综合Top25：");
    	for(String s:top25) {
    		System.out.println(s);
    	}
    }
    private void gainTop25ByLikes() throws Exception {
    	ArrayList<String> top25=hotService.getTop25ByLikes();
        System.out.println("点赞数Top25：");
    	for(String s:top25) {
    		System.out.println(s);
    	}
    }
    private void gainTop25ByFrequency() throws Exception {
    	ArrayList<String> top25=hotService.getTop25ByFrequency();
        System.out.println("播放数Top25：");
    	for(String s:top25) {
    		System.out.println(s);
    	}
    }
}
