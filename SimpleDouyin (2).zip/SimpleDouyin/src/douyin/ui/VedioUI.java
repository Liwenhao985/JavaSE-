package douyin.ui;

import douyin.entity.Comment;
import douyin.entity.Result;
import douyin.entity.User;
import douyin.service.*;
import douyin.service.Impl.*;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class VedioUI {
    private final HotService hotService = new HotServiceImpl();
    private final FollowService followService = new FollowServiceImpl();
    private final VedioService  vedioService = new VedioServiceImpl();
    private final BehaviorService behaviorService = new BehaviorServiceImpl();
    private final PushVideosRecommendation pushVideosRecommendation = new PushVideosRecommendationImpl();
    private final PullVideosRecommendation pullVideosRecommendation = new PullVideosRecommendationImpl();
    private final CommentService commentService = new CommentServiceImpl();
    private final UserTagRelationService userTagRelationService = new UserTagRelationServiceImpl();
    private final Scanner sc = new Scanner(System.in);
    //hashMap记录用户行为次数，以实现点赞、收藏、关注
    private HashMap<Integer,Integer> likes= new HashMap<>();
    private HashMap<Integer,Integer> collection= new HashMap<>();
    private HashMap<Integer,Integer> frequency= new HashMap<>();
    private HashMap<Integer,Integer> publisher= new HashMap<>();
    //tagIdList记录视频的标签id，userTagIdList记录用户标签id，vedioIdList记录视频id，
    //publisherIdList记录视频发布者id
    private ArrayList<Integer> tagIdList= new ArrayList<>();
    private ArrayList<Integer> userTagIdList= new ArrayList<>();
    private ArrayList<String> vedioList= new ArrayList<>();
    private ArrayList<Integer> vedioIdList= new ArrayList<>();
    private ArrayList<Integer> publisherIdList= new ArrayList<>();
    private int num=0;//记录当前视频在vedioList中的位置
    //begin和end记录视频播放时间，记录视频播放时间，根据时长判断是否用户是否感兴趣
    private LocalDateTime end;
    private LocalDateTime begin;


    /**
     * 显示用户视频界面并处理视频相关操作
     * 此方法呈现一个循环菜单，允许用户对视频进行各种操作，如点赞、收藏、评论等
     * 用户的选择通过控制台输入，并根据选择执行相应的操作
     *
     * @param user 用户对象，用于获取用户ID等信息
     * @return 根据用户选择返回不同的字符串，表示用户想要执行的操作
     * @throws Exception 如果操作过程中发生错误，抛出异常
     */
    public String vedioUI(User user) throws Exception{
        int choice = 0;
        while(true){
            begin= LocalDateTime.now();
            showVedio(user.getId());//内部已经num++
            System.out.println("----------------------");
            System.out.println("请选择数字:");
            System.out.println("1.点赞");
            System.out.println("2.收藏");
            System.out.println("3.评论");
            System.out.println("4.关注作者");
            System.out.println("5.查看关注者作品(逻辑相同，暂时懒得实现)");
            System.out.println("6.上一条");
            System.out.println("7.下一条");
            System.out.println("8.查看排行榜");
            System.out.println("9.查看主页");
            System.out.println("10.退出登录");
            choice = sc.nextInt();

            switch (choice){
                case 1->{
                    // 点赞
                    if(likes.get(vedioIdList.get(num))%2==0){
                        addLikes(user.getId(),vedioIdList.get(num),tagIdList.get(num));
                        likes.put(vedioIdList.get(num),likes.get(vedioIdList.get(num))+1);
                    }else{
                        deleteLikes(user.getId(),vedioIdList.get(num),tagIdList.get(num));
                        likes.put(vedioIdList.get(num),likes.get(vedioIdList.get(num))-1);
                    }
                }
                case 2->{
                    // 收藏
                    if(collection.get(vedioIdList.get(num))%2==0){
                        addCollection(user.getId(),vedioIdList.get(num),tagIdList.get(num));
                        collection.put(vedioIdList.get(num),collection.get(vedioIdList.get(num))+1);
                    }else{
                        deleteCollection(user.getId(),vedioIdList.get(num),tagIdList.get(num));
                        collection.put(vedioIdList.get(num),collection.get(vedioIdList.get(num))-1);
                    }
                }
                case 3->{
                    // 评论
                    comment(user.getId(),vedioIdList.get(num),tagIdList.get(num));
                }
                case 4->{
                    // 关注作者
                    if(publisher.get(publisherIdList.get(num))%2==0){
                        addFollow(user.getId(), publisherIdList.get(num));
                        publisher.put(publisherIdList.get(num),publisher.get(publisherIdList.get(num))+1);
                    }else{
                        deleteFollow(user.getId(), publisherIdList.get(num));
                        publisher.put(publisherIdList.get(num),publisher.get(publisherIdList.get(num))-1);
                    }
                }
                case 5->{}
                // 查看关注者作品，暂未实现
                case 6->{
                    // 上一条视频
                    if(num==0){
                        System.out.println("已经是第一条了");
                    }else{
                        end= LocalDateTime.now();
                        Duration duration = Duration.between(begin, end);
                        if(duration.toSeconds()>5){
                            play(user.getId(),vedioIdList.get(num),tagIdList.get(num));
                        }
                        num--;
                    }
                }
                case 7->{
                    // 下一条视频
                    if(num==vedioList.size()-1){
                        System.out.println("已经是最后一条了");
                    }else{
                        end= LocalDateTime.now();
                        Duration duration = Duration.between(begin, end);
                        if(duration.toSeconds()>5&&frequency.get(vedioIdList.get(num))%2==0){
                            play(user.getId(),vedioIdList.get(num),tagIdList.get(num));
                            //单个用户单次登录看这个视频的播放次数只能算作一次，不重复计数
                            frequency.put(vedioIdList.get(num),frequency.get(vedioIdList.get(num))+1);
                        }
                        num++;
                    }
                }
                case 8->{
                    // 查看排行榜
                    end= LocalDateTime.now();
                    Duration duration = Duration.between(begin, end);
                    if(duration.toSeconds()>5){
                        play(user.getId(),vedioIdList.get(num),tagIdList.get(num));
                    }
                    return "查看排行榜";
                }
                case 9-> {
                    // 查看主页
                    end = LocalDateTime.now();
                    Duration duration = Duration.between(begin, end);
                    if (duration.toSeconds() > 5) {
                        play(user.getId(), vedioIdList.get(num), tagIdList.get(num));
                    }
                    return "查看主页";
                }
                case 10->{
                    // 退出登录
                    System.out.println("退出成功,希望还能与您再次相遇");
                    return "退出登录";
                }
                default -> {
                    System.out.println("输入有误,请重新输入");
                }
            }
        }
    }

    //初始化属性变量
    public void init(int userId){
        vedioList = pushVideosRecommendation.pushVideosRecommendation(userId);
        // 初始化vedioIdList和tagIdList，publisherIdList，以及publisherMap变量
        for(String s : vedioList){
            vedioIdList.add(vedioService.getVedioIdByPath(s));
            tagIdList.add(vedioService.getTagIdByVedioId(vedioIdList.get(vedioIdList.size()-1)));
            publisherIdList.add(vedioService.getUserIdByVedioPath(s));
            publisher.put(publisherIdList.get(vedioIdList.size()-1),0);
        }
        //  初始化userTagIdList
        userTagIdList=userTagRelationService.getTagIdByUserId(userId);
        //  初始化hashMap
        for(int i:vedioIdList){
            likes.put(i,0);
            collection.put(i,0);
            frequency.put(i,0);
        }
    }//该方法在创建对象时单独调用一次

    //添加关注与取消关注（对当前视频作者）
    private void addFollow(int userId, int followId) {
        // 若已经关注或者关注失败
        if(!followService.addFollowRelation(userId, followId)){
            System.out.println("添加关注失败/已关注");
            return;
        }
        System.out.println("添加关注成功");
        // 检查是否双向关注，是则成为好友
        Result result2=followService.updateTwoWay(userId, followId);
        if(!result2.isOK()){
            System.out.println("添加交友失败");
            return;
        }
        System.out.println("你们成为了好友！");
    }
    private void deleteFollow(int userId, int followId) {
        Result result2=followService.deleteTwoWay(userId, followId);
        if(!result2.isOK()){
            System.out.println("删除交友失败");
            return;
        }
        Result result1 =followService.deleteFollowRelation(userId, followId);
        if(!result1.isOK()){
            System.out.println("取消关注失败");
            return;
        }
        System.out.println("取消关注成功");
    }

    //点赞与取消点赞
    private void addLikes(int userId, int vedioId,int tagId) {
        //添加行为
        Result result1 =behaviorService.addBehavior(userId, vedioId, "点赞", LocalDateTime.now());
        if(!result1.isOK()){
            System.out.println("behaviour点赞失败");
            return;
        }
        //添加热度中的点赞数
        if(hotService.addLikes(vedioId)){
            System.out.println("hot添加点赞成功");
        }else{
            System.out.println("hot添加点赞失败");
        }
        //添加weight
        userAddWeight(userId, tagId);
    }
    private void deleteLikes(int userId, int vedioId,int tagId) {
        //删除行为
        Result result1 =behaviorService.deleteBehavior(userId,vedioId,"点赞");
        if(!result1.isOK()){
            System.out.println("behaviour删除点赞失败");
            return;
        }
        //删除热度中的点赞数
        if(hotService.cutLikes(vedioId)){
            System.out.println("hot删除点赞成功");
        }else{
            System.out.println("hot删除点赞失败");
        }
        //删除weight
        userCutWeight(userId, tagId);
    }
    private void userAddWeight(int userId, int tagId) {
        if(userTagIdList.contains(tagId)){
            if(userTagRelationService.addWeight(userId, tagId).isOK()){
                System.out.println("添加weight成功");
            }else{
                System.out.println("添加weight失败");
            }
        }else{
            if(userTagRelationService.addUseTagRelation(userId, tagId).isOK()){
                System.out.println("添加userTagRelation成功");
            }else{
                System.out.println("添加userTagRelation失败");
            }
        }
    }

    //收藏与取消收藏
    private void addCollection(int userId, int vedioId,int tagId) {
        //添加行为
        Result result1 =behaviorService.addBehavior(userId, vedioId, "收藏", LocalDateTime.now());
        if(!result1.isOK()){
            System.out.println("behaviour收藏失败");
            return;
        }
        //添加热度中的收藏数
        if(hotService.addCollection(vedioId)){
            System.out.println("hot添加收藏成功");
        }else{
            System.out.println("hot添加收藏失败");
        }
        //添加weight
        userAddWeight(userId, tagId);
    }
    private void deleteCollection(int userId, int vedioId,int tagId) {
        //删除行为
        Result result1 =behaviorService.deleteBehavior(userId,vedioId,"收藏");
        if(!result1.isOK()){
            System.out.println("behaviour删除收藏失败");
            return;
        }
        //删除热度中的收藏数
        if(hotService.cutCollection(vedioId)){
            System.out.println("hot删除收藏成功");
        }else{
            System.out.println("hot删除收藏失败");
        }
        //删除weight
        userCutWeight(userId, tagId);
    }
    private void userCutWeight(int userId, int tagId) {
        if(userTagIdList.contains(tagId)){
            if(userTagRelationService.cutWeight(userId, tagId).isOK()){
                System.out.println("删除weight成功");
            }else{
                System.out.println("删除weight失败");
            }
        }
    }

    //评论与删除评论
    private void comment(int userId, int vedioId,int tagId){
        int choice = 0;
        while (true) {
            System.out.println("----------------------------");
            System.out.println("当前视频的评论：");
            showComment(vedioId);
            System.out.println("----------------------------");
            System.out.println("请选择数字：");
            System.out.println("1.添加评论");
            System.out.println("2.回复(目前只能回复父评论)");
            System.out.println("3.删除评论(只能删除自己的评论)");
            System.out.println("4.返回");
            choice = sc.nextInt();

            switch (choice){
                case 1->{addComment(userId, vedioId, tagId);}
                case 2->{review(userId, vedioId, tagId);}
                case 3->{deleteComment(userId, vedioId, tagId);}
                case 4->{return;}
            }
        }
    }
    private void addComment(int userId, int vedioId,int tagId) {
        System.out.println("请输入评论内容：");
        String comment = sc.next();
        //添加行为
        Result result1 =behaviorService.addBehavior(userId, vedioId, "评论", LocalDateTime.now());
        if(!result1.isOK()){
            System.out.println("behaviour评论失败");
            return;
        }
        //添加weight
        userAddWeight(userId, tagId);
        //添加评论
        if(commentService.addNormalComment(userId, vedioId, comment, LocalDateTime.now()).isOK()){
            System.out.println("评论成功");
        }else{
            System.out.println("评论失败");
        }
    }
    private void review(int userId, int vedioId,int tagId) {
        System.out.println("请输入要回复的评论id：");
        int parentId = sc.nextInt();
        System.out.println("请输入回复内容：");
        String content = sc.next();
        //添加行为
        Result result1 =behaviorService.addBehavior(userId, vedioId, "评论", LocalDateTime.now());
        if(!result1.isOK()){
            System.out.println("behaviour评论失败");
            return;
        }
        //添加weight
        userAddWeight(userId, tagId);
        //回复
        if(commentService.review(userId, vedioId, parentId, content, LocalDateTime.now()).isOK()){
            System.out.println("回复成功");
        }else{
            System.out.println("回复失败");
        }
    }
    private void deleteComment(int userId, int vedioId,int tagId) {
        System.out.println("请输入要删除的评论id：");
        int id = sc.nextInt();
        //删除行为
        Result result1 =behaviorService.deleteBehavior(userId,vedioId,"评论");
        if(!result1.isOK()){
            System.out.println("behaviour删除评论失败");
            return;
        }
        //删除weight
        userCutWeight(userId, tagId);
        //删除评论
        if(commentService.deleteComment(id, userId).isOK()){
            System.out.println("删除评论成功");
        }else{
            System.out.println("删除评论失败");
        }
    }
    private void showComment(int vedioId) {
        ArrayList<Comment> parentComments = commentService.getParentCommentByVedioId(vedioId);
        for (Comment comment : parentComments) {
            ArrayList<Comment> kidComments = commentService.getKidCommentByParentId(comment.getId());
            System.out.println(comment.getContent()+"  发布者："+comment.getUserid());
            System.out.println("发布时间："+comment.getTime()+"  评论ID："+comment.getId());
            for (Comment kidComment : kidComments) {
                System.out.println("    " + kidComment+"  发布者："+kidComment.getUserid());
                System.out.println("     发布时间："+kidComment.getTime()+"  评论ID："+kidComment.getId());
            }
        }
    }

    //展示视频
    private void showVedio(int userId) {
        System.out.println("----------------------------");
        //已经全部展示
        if(num==vedioList.size()){
            System.out.println(num);
            System.out.println("没有更多视频了");
            return;
        }
        System.out.println("当前视频："+ vedioList.get(num)+"  发布者："+publisherIdList.get(num));
        //剩余视频数量不足十个时补充数量，实现滚动功能
        if(num==vedioList.size()-10){
            ArrayList<String> list = pushVideosRecommendation.append(userId);
            vedioList.addAll(list);
            for(String s : list){
                vedioIdList.add(vedioService.getVedioIdByPath(s));
                tagIdList.add(vedioService.getTagIdByVedioId(vedioIdList.get(vedioIdList.size()-1)));
                publisherIdList.add(vedioService.getUserIdByVedioPath(s));
            }
        }
    }

    //播放相关（UserTag,Hot)
    private void play(int userId, int vedioId,int tagId) {
        //添加Weight
        userAddWeight(userId, tagId);
        //添加热度的Frequency
        if(hotService.addFrequency(vedioId)){
            System.out.println("hot添加frequency成功");
        }else{
            System.out.println("hot添加frequency失败");
        }
    }
}
